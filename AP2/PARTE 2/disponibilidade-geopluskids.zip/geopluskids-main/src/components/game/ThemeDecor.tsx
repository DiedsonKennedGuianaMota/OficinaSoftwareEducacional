import type { ThemeId } from "@/lib/game/constants";

/**
 * Decorative background layer. Sits BEHIND all UI (z:-10) and is non-interactive.
 * Uses low opacity + scattered SVG so cards/buttons never look obscured.
 */
export default function ThemeDecor({ theme }: { theme: ThemeId }) {
  if (theme === "default") return null;
  return (
    <div
      aria-hidden
      className="pointer-events-none fixed inset-0 overflow-hidden"
      style={{ zIndex: -10 }}
    >
      {theme === "halloween" && <Halloween />}
      {theme === "hellokitty" && <HelloKitty />}
      {theme === "kuromi" && <Kuromi />}
      {theme === "space" && <Space />}
      {theme === "ocean" && <Ocean />}
      {theme === "soccer" && <Soccer />}
      {theme === "horror" && <Horror />}
    </div>
  );
}

function Item({ i, n, children, scale = 1, opacity = 0.35 }: { i: number; n: number; children: React.ReactNode; scale?: number; opacity?: number }) {
  const x = ((i * 73) % 92) + 4;
  const y = ((i * 131) % 88) + 6;
  const delay = (i % n) * 0.4;
  return (
    <span
      className="absolute float"
      style={{
        top: `${y}%`,
        left: `${x}%`,
        animationDelay: `${delay}s`,
        opacity,
        transform: `scale(${scale})`,
      }}
    >
      {children}
    </span>
  );
}

function Pumpkin() {
  return (
    <svg width="42" height="42" viewBox="0 0 42 42">
      <ellipse cx="21" cy="24" rx="16" ry="13" fill="#f97316" />
      <path d="M21 11 Q23 6 27 8" stroke="#15803d" strokeWidth="2.5" fill="none" strokeLinecap="round" />
      <path d="M14 22 L17 26 L20 22 Z M22 22 L25 26 L28 22 Z" fill="#1f2937" />
      <path d="M13 30 Q21 35 29 30 L27 33 L24 31 L21 33 L18 31 L15 33 Z" fill="#1f2937" />
    </svg>
  );
}
function Ghost() {
  return (
    <svg width="36" height="40" viewBox="0 0 36 40">
      <path d="M4 16 Q4 4 18 4 Q32 4 32 16 L32 36 L28 32 L24 36 L20 32 L16 36 L12 32 L8 36 L4 32 Z" fill="#fff" />
      <circle cx="14" cy="18" r="2.5" fill="#1f2937" />
      <circle cx="22" cy="18" r="2.5" fill="#1f2937" />
    </svg>
  );
}
function Web() {
  return (
    <svg width="44" height="44" viewBox="0 0 44 44" fill="none" stroke="#1f2937" strokeWidth="1.2">
      <path d="M2 2 L42 42 M2 42 L42 2 M22 2 V42 M2 22 H42" />
      <path d="M22 8 L16 14 L22 20 L28 14 Z M22 24 L14 28 L22 36 L30 28 Z" />
    </svg>
  );
}
function Bat() {
  return (
    <svg width="40" height="22" viewBox="0 0 40 22">
      <path d="M20 4 Q14 14 2 10 Q8 18 14 16 L20 14 L26 16 Q32 18 38 10 Q26 14 20 4 Z" fill="#1f2937" />
    </svg>
  );
}

function Halloween() {
  const els = [Pumpkin, Ghost, Web, Bat];
  return (
    <>
      {Array.from({ length: 10 }).map((_, i) => {
        const C = els[i % els.length];
        return <Item key={i} i={i} n={els.length} opacity={0.28}><C /></Item>;
      })}
    </>
  );
}

function Bow() {
  return (
    <svg width="34" height="22" viewBox="0 0 34 22">
      <path d="M17 11 L4 4 L4 18 Z" fill="#ec4899" />
      <path d="M17 11 L30 4 L30 18 Z" fill="#ec4899" />
      <circle cx="17" cy="11" r="3.5" fill="#be185d" />
    </svg>
  );
}
function KittyHead() {
  return (
    <svg width="38" height="32" viewBox="0 0 38 32">
      <path d="M6 12 L4 4 L12 10 Z M32 12 L34 4 L26 10 Z" fill="#fff" stroke="#1f2937" strokeWidth="1" />
      <ellipse cx="19" cy="18" rx="14" ry="12" fill="#fff" stroke="#1f2937" strokeWidth="1" />
      <circle cx="13" cy="18" r="1.6" fill="#1f2937" />
      <circle cx="25" cy="18" r="1.6" fill="#1f2937" />
      <ellipse cx="19" cy="22" rx="1.6" ry="1.2" fill="#fbbf24" />
      <path d="M10 24 H6 M10 22 H4 M28 24 H32 M28 22 H34" stroke="#1f2937" strokeWidth="0.8" />
    </svg>
  );
}
function HelloKitty() {
  const els = [Bow, KittyHead];
  return (
    <>
      {Array.from({ length: 10 }).map((_, i) => {
        const C = els[i % els.length];
        return <Item key={i} i={i} n={els.length} opacity={0.32}><C /></Item>;
      })}
    </>
  );
}

function Skull() {
  return (
    <svg width="32" height="34" viewBox="0 0 32 34">
      <path d="M16 2 Q4 2 4 16 L4 22 L8 22 L8 28 L12 28 L12 32 L20 32 L20 28 L24 28 L24 22 L28 22 L28 16 Q28 2 16 2 Z" fill="#fff" stroke="#1f2937" strokeWidth="1.5" />
      <circle cx="11" cy="16" r="2.5" fill="#1f2937" />
      <circle cx="21" cy="16" r="2.5" fill="#1f2937" />
    </svg>
  );
}
function Moon() {
  return <svg width="32" height="32" viewBox="0 0 32 32"><path d="M22 4 A12 12 0 1 0 28 22 A9 9 0 0 1 22 4 Z" fill="#a78bfa" /></svg>;
}
function Kuromi() {
  const els = [Skull, Moon];
  return (
    <>
      {Array.from({ length: 10 }).map((_, i) => {
        const C = els[i % els.length];
        return <Item key={i} i={i} n={els.length} opacity={0.3}><C /></Item>;
      })}
    </>
  );
}

function Planet() {
  return (
    <svg width="44" height="32" viewBox="0 0 44 32">
      <circle cx="20" cy="16" r="10" fill="#60a5fa" />
      <ellipse cx="22" cy="16" rx="20" ry="4" fill="none" stroke="#facc15" strokeWidth="1.5" />
    </svg>
  );
}
function Rocket() {
  return (
    <svg width="22" height="34" viewBox="0 0 22 34">
      <path d="M11 2 Q4 12 4 22 L8 28 L14 28 L18 22 Q18 12 11 2 Z" fill="#e5e7eb" />
      <circle cx="11" cy="14" r="3" fill="#0ea5e9" />
      <path d="M4 22 L0 30 L8 28 Z M18 22 L22 30 L14 28 Z" fill="#ef4444" />
      <path d="M9 28 L13 28 L11 34 Z" fill="#f59e0b" />
    </svg>
  );
}
function Sparkle() {
  return <svg width="14" height="14" viewBox="0 0 14 14"><path d="M7 0 L8 6 L14 7 L8 8 L7 14 L6 8 L0 7 L6 6 Z" fill="#fde047" /></svg>;
}
function Space() {
  return (
    <>
      {Array.from({ length: 22 }).map((_, i) => (
        <Item key={"s" + i} i={i} n={6} opacity={0.55} scale={0.6 + (i % 3) * 0.3}><Sparkle /></Item>
      ))}
      {Array.from({ length: 4 }).map((_, i) => (
        <Item key={"p" + i} i={i * 7 + 3} n={4} opacity={0.4}><Planet /></Item>
      ))}
      {Array.from({ length: 3 }).map((_, i) => (
        <Item key={"r" + i} i={i * 11 + 5} n={3} opacity={0.45}><Rocket /></Item>
      ))}
    </>
  );
}

function Fish() {
  return (
    <svg width="36" height="22" viewBox="0 0 36 22">
      <path d="M2 11 Q10 2 24 4 Q34 6 34 11 Q34 16 24 18 Q10 20 2 11 Z" fill="#06b6d4" />
      <path d="M2 11 L-2 4 L-2 18 Z" fill="#06b6d4" transform="translate(2,0)" />
      <circle cx="28" cy="10" r="1.8" fill="#fff" />
      <circle cx="28" cy="10" r="0.8" fill="#1f2937" />
    </svg>
  );
}
function Bubble() {
  return <svg width="16" height="16" viewBox="0 0 16 16"><circle cx="8" cy="8" r="6" fill="none" stroke="#0ea5e9" strokeWidth="1.2" /><circle cx="6" cy="6" r="1.5" fill="#bae6fd" /></svg>;
}
function Ocean() {
  return (
    <>
      {Array.from({ length: 8 }).map((_, i) => <Item key={"f" + i} i={i} n={4} opacity={0.35}><Fish /></Item>)}
      {Array.from({ length: 10 }).map((_, i) => <Item key={"b" + i} i={i * 5 + 2} n={5} opacity={0.5}><Bubble /></Item>)}
    </>
  );
}

function Ball() {
  return (
    <svg width="28" height="28" viewBox="0 0 28 28">
      <circle cx="14" cy="14" r="12" fill="#fff" stroke="#1f2937" strokeWidth="1.2" />
      <polygon points="14,8 18,11 16,16 12,16 10,11" fill="#1f2937" />
    </svg>
  );
}
function Soccer() {
  return <>{Array.from({ length: 9 }).map((_, i) => <Item key={i} i={i} n={3} opacity={0.32}><Ball /></Item>)}</>;
}

function Horror() {
  return <>{Array.from({ length: 10 }).map((_, i) => <Item key={i} i={i} n={4} opacity={0.22}><Bat /></Item>)}</>;
}
