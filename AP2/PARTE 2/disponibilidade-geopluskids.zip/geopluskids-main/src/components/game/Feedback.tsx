export function Feedback({ kind, message }: { kind: "ok" | "err" | null; message: string }) {
  if (!kind) return null;
  return (
    <div
      role="status"
      className={`pop-in rounded-2xl p-3 font-display text-lg font-bold ${
        kind === "ok" ? "bg-success/20 text-success-foreground" : "bg-destructive/20 text-destructive shake"
      }`}
    >
      {kind === "ok" ? "✅ " : "❌ "}{message}
    </div>
  );
}
