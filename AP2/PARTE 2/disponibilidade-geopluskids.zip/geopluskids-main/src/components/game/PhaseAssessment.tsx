import { useMemo, useState } from "react";
import { useProfile } from "@/lib/game/ProfileContext";
import { saveAssessment, addXp } from "@/lib/game/profile";
import { SpeakButton } from "./Speak";
import { toast } from "sonner";

type Q =
  | { kind: "loc"; question: string; correct: "left" | "right" | "front" | "back" }
  | { kind: "solid"; question: string; options: string[]; correct: string }
  | { kind: "plane"; question: string; options: { emoji: string; id: string }[]; correct: string };

const POOL: Q[] = [
  { kind: "loc", question: "O cachorro está à sua...", correct: "left" },
  { kind: "loc", question: "A árvore está...", correct: "front" },
  { kind: "loc", question: "A mochila está à sua...", correct: "right" },
  { kind: "loc", question: "O gato está...", correct: "back" },
  { kind: "solid", question: "Qual é a bola?", options: ["⚽", "📦", "🥫", "🍦"], correct: "⚽" },
  { kind: "solid", question: "Qual é a caixa?", options: ["📦", "🥎", "🎂", "🥕"], correct: "📦" },
  { kind: "solid", question: "Qual rola?", options: ["🥫", "📕", "🧊", "🎁"], correct: "🥫" },
  { kind: "plane", question: "Encontre o círculo", options: [
    { emoji: "🔴", id: "circle" }, { emoji: "🟦", id: "square" }, { emoji: "🔺", id: "tri" }
  ], correct: "circle" },
  { kind: "plane", question: "Encontre o triângulo", options: [
    { emoji: "🟧", id: "square" }, { emoji: "🔺", id: "tri" }, { emoji: "🟣", id: "circle" }
  ], correct: "tri" },
  { kind: "plane", question: "Encontre o quadrado", options: [
    { emoji: "🟩", id: "square" }, { emoji: "🔵", id: "circle" }, { emoji: "🔻", id: "tri" }
  ], correct: "square" },
];

export default function PhaseAssessment({ onBack }: { onBack: () => void }) {
  const { profile, refresh } = useProfile();
  const questions = useMemo(() => shuffle(POOL).slice(0, 10), []);
  const [i, setI] = useState(0);
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(3);
  const [feedback, setFeedback] = useState<"ok" | "no" | null>(null);
  const [done, setDone] = useState(false);

  const cur = questions[i];

  const answer = (val: string) => {
    if (feedback) return;
    const correct = (cur.kind === "loc" && val === cur.correct) ||
      (cur.kind === "solid" && val === cur.correct) ||
      (cur.kind === "plane" && val === cur.correct);
    if (correct) {
      setScore((s) => s + 1);
      setFeedback("ok");
    } else {
      setLives((l) => Math.max(0, l - 1));
      setFeedback("no");
    }
    setTimeout(async () => {
      setFeedback(null);
      if (i + 1 >= questions.length || (lives <= 1 && !correct)) {
        await finish(correct ? score + 1 : score);
      } else {
        setI((x) => x + 1);
      }
    }, 900);
  };

  const finish = async (final: number) => {
    if (!profile) return;
    const stars = final >= 9 ? 3 : final >= 6 ? 2 : final >= 3 ? 1 : 0;
    const xp = final * 10 + stars * 20;
    await saveAssessment(profile.id, final, stars, questions.length, { lives });
    await addXp(profile.id, xp);
    await refresh();
    toast.success(`Você ganhou ${xp} XP! 🎉`);
    setDone(true);
  };

  if (done) {
    const stars = score >= 9 ? 3 : score >= 6 ? 2 : score >= 3 ? 1 : 0;
    return (
      <div className="card-toy text-center pop-in">
        <div className="text-6xl">🏆</div>
        <h2 className="font-display text-3xl font-bold mt-2">Avaliação concluída!</h2>
        <div className="text-yellow-500 text-3xl mt-2">{"⭐".repeat(stars) || "💙"}</div>
        <p className="text-lg mt-2">Você acertou <b>{score}</b> de {questions.length}.</p>
        <button onClick={onBack} className="btn-toy btn-primary mt-5">🏠 Voltar</button>
      </div>
    );
  }

  return (
    <div className="card-toy">
      <div className="flex justify-between items-center mb-3">
        <button onClick={onBack} className="btn-toy btn-secondary !py-2 !px-3 !text-sm">← Sair</button>
        <div className="font-display">{i + 1}/{questions.length}</div>
        <div className="text-2xl">{"❤️".repeat(lives)}{"🖤".repeat(3 - lives)}</div>
      </div>
      <div className="h-2 rounded-full bg-muted overflow-hidden mb-4">
        <div className="h-full bg-primary transition-all" style={{ width: `${((i) / questions.length) * 100}%` }} />
      </div>

      <div className={`text-center ${feedback === "no" ? "shake" : ""}`}>
        <div className="text-5xl mb-2">{cur.kind === "loc" ? "🧭" : cur.kind === "solid" ? "📦" : "🔷"}</div>
        <div className="flex items-center justify-center gap-2">
          <h3 className="font-display text-2xl font-bold">{cur.question}</h3>
          <SpeakButton text={cur.question} />
        </div>

        <div className="mt-5 grid grid-cols-2 gap-3">
          {cur.kind === "loc" && (
            <>
              {(["left", "front", "right", "back"] as const).map((dir) => (
                <button key={dir} onClick={() => answer(dir)} className="btn-toy btn-secondary !text-base">
                  {dir === "left" ? "⬅️ Esquerda" : dir === "right" ? "Direita ➡️" : dir === "front" ? "⬆️ Frente" : "⬇️ Atrás"}
                </button>
              ))}
            </>
          )}
          {cur.kind === "solid" && cur.options.map((o) => (
            <button key={o} onClick={() => answer(o)} className="rounded-2xl bg-card shadow p-6 text-5xl hover:scale-105 transition">{o}</button>
          ))}
          {cur.kind === "plane" && cur.options.map((o) => (
            <button key={o.id} onClick={() => answer(o.id)} className="rounded-2xl bg-card shadow p-6 text-5xl hover:scale-105 transition">{o.emoji}</button>
          ))}
        </div>

        {feedback === "ok" && <div className="mt-4 text-3xl pop-in">✅ Boa!</div>}
        {feedback === "no" && <div className="mt-4 text-3xl pop-in">❌ Quase!</div>}
      </div>
    </div>
  );
}

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
