import { useState } from "react";
import { FRUITS, randomFruitPassword, type FruitId } from "@/lib/game/constants";
import { loginChild, signUpChild, findUsername, loginTeacher, signUpTeacher } from "@/lib/game/auth";
import { toast } from "sonner";
import { SpeakButton } from "./Speak";

type Role = "student" | "teacher" | null;

export default function AuthScreen({ onAuthed }: { onAuthed: () => void }) {
  const [role, setRole] = useState<Role>(null);
  const [mode, setMode] = useState<"login" | "signup">("login");

  return (
    <div className="mx-auto max-w-xl px-4 py-10">
      <div className="card-toy text-center relative overflow-hidden">
        <FloatingBlob />
        <h1 className="font-display text-5xl font-bold text-primary tracking-tight">
          🎮 GeoPlus<span className="text-secondary">Kids</span>
        </h1>
        <p className="mt-2 text-muted-foreground font-display">Aventura geométrica para todo mundo</p>

        {!role && (
          <div className="mt-8 grid grid-cols-2 gap-4">
            <button onClick={() => setRole("student")} className="rounded-3xl bg-gradient-to-br from-pink-400 to-red-400 p-6 text-white shadow-lg hover:-translate-y-1 transition">
              <div className="text-6xl float">🧒</div>
              <div className="mt-2 font-display font-bold text-xl">Sou Aluno</div>
            </button>
            <button onClick={() => setRole("teacher")} className="rounded-3xl bg-gradient-to-br from-sky-400 to-blue-600 p-6 text-white shadow-lg hover:-translate-y-1 transition">
              <div className="text-6xl float">👩‍🏫</div>
              <div className="mt-2 font-display font-bold text-xl">Sou Professor</div>
            </button>
          </div>
        )}

        {role && (
          <>
            <button onClick={() => setRole(null)} className="mt-4 text-sm underline text-muted-foreground">← Trocar perfil</button>
            <div className="mt-3 flex justify-center gap-2">
              <button className={`btn-toy ${mode === "login" ? "btn-primary" : "btn-secondary"}`} onClick={() => setMode("login")}>Entrar</button>
              <button className={`btn-toy ${mode === "signup" ? "btn-primary" : "btn-secondary"}`} onClick={() => setMode("signup")}>Criar conta</button>
            </div>
            {role === "student" ? (
              mode === "login" ? <LoginForm onAuthed={onAuthed} /> : <SignupForm onAuthed={onAuthed} />
            ) : mode === "login" ? <TeacherLogin onAuthed={onAuthed} /> : <TeacherSignup onAuthed={onAuthed} />}
          </>
        )}
      </div>
    </div>
  );
}

function FloatingBlob() {
  return (
    <div aria-hidden className="pointer-events-none absolute -top-10 -right-10 w-40 h-40 rounded-full bg-accent/40 blur-2xl float" />
  );
}

function FruitPad({ selected, onPick, onClear, max }: { selected: FruitId[]; onPick: (id: FruitId) => void; onClear: () => void; max: number }) {
  return (
    <div>
      <div className="mb-3 flex flex-wrap justify-center gap-2 min-h-14 rounded-2xl bg-muted p-2">
        {selected.map((id, i) => (
          <span key={i} className="text-3xl pop-in">{FRUITS.find((f) => f.id === id)!.emoji}</span>
        ))}
        {selected.length === 0 && <span className="text-sm text-muted-foreground">Clique nas frutas na ordem</span>}
      </div>
      <div className="grid grid-cols-4 gap-2">
        {FRUITS.map((f) => (
          <button key={f.id} type="button" disabled={selected.length >= max} onClick={() => onPick(f.id)} className="rounded-2xl bg-card p-3 text-4xl shadow hover:scale-110 active:scale-95 transition disabled:opacity-40" aria-label={f.name}>
            {f.emoji}
          </button>
        ))}
      </div>
      <button type="button" onClick={onClear} className="mt-2 text-sm text-muted-foreground underline">Limpar</button>
    </div>
  );
}

function LoginForm({ onAuthed }: { onAuthed: () => void }) {
  const [name, setName] = useState("");
  const [fruits, setFruits] = useState<FruitId[]>([]);
  const [loading, setLoading] = useState(false);
  const submit = async () => {
    if (!name.trim() || fruits.length < 4) return toast.error("Escreva seu nome e escolha 4 frutas.");
    setLoading(true);
    try { await loginChild(name, fruits); onAuthed(); }
    catch (e) { toast.error((e as Error).message); }
    finally { setLoading(false); }
  };
  return (
    <div className="mt-6 text-left">
      <label className="font-display font-bold">Seu nome</label>
      <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex: Lia" className="mt-1 w-full rounded-xl border-2 border-border bg-background p-3 text-lg" />
      <div className="mt-4 flex items-center gap-2">
        <p className="font-display font-bold">Sua senha de frutas</p>
        <SpeakButton text="Clique nas frutas da sua senha na ordem certa." />
      </div>
      <div className="mt-2">
        <FruitPad selected={fruits} onPick={(id) => setFruits([...fruits, id])} onClear={() => setFruits([])} max={4} />
      </div>
      <button onClick={submit} disabled={loading} className="btn-toy btn-primary mt-5 w-full">{loading ? "Entrando..." : "🎮 Entrar"}</button>
    </div>
  );
}

function SignupForm({ onAuthed }: { onAuthed: () => void }) {
  const [name, setName] = useState("");
  const [age, setAge] = useState(6);
  const [generated, setGenerated] = useState<FruitId[] | null>(null);
  const [loading, setLoading] = useState(false);

  const generate = async () => {
    if (!name.trim()) return toast.error("Escreva seu nome.");
    const exists = await findUsername(name);
    if (exists) return toast.error("Esse nome já existe. Tente outro.");
    setGenerated(randomFruitPassword(4));
  };

  const confirm = async () => {
    if (!generated) return;
    setLoading(true);
    try { await signUpChild({ username: name, age, fruits: generated }); toast.success("Conta criada! 🎉"); onAuthed(); }
    catch (e) { toast.error((e as Error).message); }
    finally { setLoading(false); }
  };

  return (
    <div className="mt-6 text-left">
      <label className="font-display font-bold">Seu nome</label>
      <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex: Lia" className="mt-1 w-full rounded-xl border-2 border-border bg-background p-3 text-lg" />
      <label className="font-display font-bold mt-4 block">Sua idade</label>
      <div className="flex gap-2 mt-1">
        {[5, 6, 7, 8, 9, 10].map((n) => (
          <button key={n} type="button" onClick={() => setAge(n)} className={`flex-1 rounded-xl p-3 font-bold text-lg ${age === n ? "bg-primary text-primary-foreground" : "bg-muted"}`}>{n}</button>
        ))}
      </div>
      {!generated ? (
        <button onClick={generate} className="btn-toy btn-primary mt-5 w-full">🍓 Criar minha senha de frutas</button>
      ) : (
        <div className="mt-5 rounded-2xl bg-accent/20 p-4">
          <div className="flex items-center justify-between">
            <p className="font-display font-bold">Sua senha (memorize!):</p>
            <SpeakButton text={`Sua senha é ${generated.map((id) => FRUITS.find((f) => f.id === id)!.name).join(", ")}`} />
          </div>
          <div className="my-3 flex justify-center gap-2 text-5xl">
            {generated.map((id, i) => (<span key={i} className="pop-in">{FRUITS.find((f) => f.id === id)!.emoji}</span>))}
          </div>
          <p className="text-xs text-muted-foreground text-center">📸 Tire uma foto ou mostre a um adulto.</p>
          <div className="mt-4 flex gap-2">
            <button onClick={() => setGenerated(null)} className="btn-toy btn-secondary flex-1">Sortear outra</button>
            <button onClick={confirm} disabled={loading} className="btn-toy btn-primary flex-1">{loading ? "..." : "✓ Continuar"}</button>
          </div>
        </div>
      )}
    </div>
  );
}

function TeacherLogin({ onAuthed }: { onAuthed: () => void }) {
  const [email, setEmail] = useState(""); const [pwd, setPwd] = useState(""); const [loading, setLoading] = useState(false);
  const submit = async () => {
    if (!email || !pwd) return toast.error("Preencha email e senha.");
    setLoading(true);
    try { await loginTeacher(email, pwd); onAuthed(); }
    catch (e) { toast.error((e as Error).message); }
    finally { setLoading(false); }
  };
  return (
    <div className="mt-6 text-left space-y-3">
      <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" type="email" className="w-full rounded-xl border-2 border-border bg-background p-3" />
      <input value={pwd} onChange={(e) => setPwd(e.target.value)} placeholder="Senha" type="password" className="w-full rounded-xl border-2 border-border bg-background p-3" />
      <button onClick={submit} disabled={loading} className="btn-toy btn-primary w-full">{loading ? "..." : "Entrar"}</button>
    </div>
  );
}

function TeacherSignup({ onAuthed }: { onAuthed: () => void }) {
  const [name, setName] = useState(""); const [email, setEmail] = useState(""); const [pwd, setPwd] = useState(""); const [loading, setLoading] = useState(false);
  const submit = async () => {
    if (!name || !email || pwd.length < 6) return toast.error("Preencha nome, email e senha (mín. 6).");
    setLoading(true);
    try { await signUpTeacher({ name, email, password: pwd }); toast.success("Conta criada!"); onAuthed(); }
    catch (e) { toast.error((e as Error).message); }
    finally { setLoading(false); }
  };
  return (
    <div className="mt-6 text-left space-y-3">
      <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Seu nome" className="w-full rounded-xl border-2 border-border bg-background p-3" />
      <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" type="email" className="w-full rounded-xl border-2 border-border bg-background p-3" />
      <input value={pwd} onChange={(e) => setPwd(e.target.value)} placeholder="Senha (mín. 6)" type="password" className="w-full rounded-xl border-2 border-border bg-background p-3" />
      <button onClick={submit} disabled={loading} className="btn-toy btn-primary w-full">{loading ? "..." : "Criar conta"}</button>
    </div>
  );
}
