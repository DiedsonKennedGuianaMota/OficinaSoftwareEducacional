import { useEffect, useState } from "react";
import { Play, BarChart3, User, Palette, Accessibility, Trophy, Lock, MapPin, Box, Shapes } from "lucide-react";
import { useProfile } from "@/lib/game/ProfileContext";
import { AvatarRenderer } from "./AvatarRenderer";
import { loadProgress } from "@/lib/game/profile";
import ThemeDecor from "./ThemeDecor";

type View = "home" | "play" | "progress" | "avatar" | "themes" | "a11y" | "assessment";

export default function Home({
  onNavigate, onPlay, onAssessment,
}: { onNavigate: (v: View) => void; onPlay: () => void; onAssessment: () => void }) {
  const { profile, signOut } = useProfile();
  const [progress, setProgress] = useState<{ phase: number; level: number; best_stars: number }[]>([]);

  useEffect(() => {
    if (profile) loadProgress(profile.id).then(setProgress);
  }, [profile]);

  if (!profile) return null;

  const totalStars = progress.reduce((s, p) => s + (p.best_stars || 0), 0);
  const phasesDone = progress.filter((p) => p.level >= 5).length;
  const canAssess = phasesDone >= 3;
  const nextPhase = Math.min(3, phasesDone + 1);

  const orbit: { id: View; label: string; icon: typeof BarChart3; gradient: string }[] = [
    { id: "progress", label: "Progresso", icon: BarChart3, gradient: "from-emerald-400 to-teal-500" },
    { id: "avatar", label: "Meu Avatar", icon: User, gradient: "from-amber-300 to-orange-400" },
    { id: "themes", label: "Tema", icon: Palette, gradient: "from-purple-400 to-fuchsia-500" },
    { id: "a11y", label: "Acessibilidade", icon: Accessibility, gradient: "from-sky-400 to-blue-500" },
  ];

  const phaseInfo = [
    { title: "Localização", icon: MapPin, gradient: "from-rose-400 to-pink-500" },
    { title: "Sólidos", icon: Box, gradient: "from-amber-400 to-orange-500" },
    { title: "Formas", icon: Shapes, gradient: "from-violet-500 to-fuchsia-500" },
  ];

  return (
    <div className="relative space-y-5">
      <ThemeDecor theme={profile.theme} />

      {/* Profile header */}
      <div className="card-toy flex items-center gap-4">
        <div className="shrink-0"><AvatarRenderer a={profile.avatar} size={96} /></div>
        <div className="flex-1 min-w-0">
          <div className="font-display text-2xl font-bold truncate">Olá, {profile.display_name || profile.username}!</div>
          <div className="flex items-center gap-3 text-sm mt-1">
            <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 text-amber-800 px-2 py-0.5 font-bold">
              <Trophy className="w-3.5 h-3.5" /> {profile.xp} XP
            </span>
            <span className="text-muted-foreground">{totalStars} estrelinhas</span>
          </div>
          <div className="mt-2 h-2 rounded-full bg-muted overflow-hidden">
            <div className="h-full bg-gradient-to-r from-primary to-secondary transition-all" style={{ width: `${Math.min(100, (phasesDone / 3) * 100)}%` }} />
          </div>
        </div>
      </div>

      {/* Big play button */}
      <button
        onClick={onPlay}
        className="group relative w-full rounded-[2rem] bg-gradient-to-br from-rose-500 via-orange-500 to-amber-400 p-7 text-white shadow-[0_12px_0_0_rgba(0,0,0,0.15)] active:translate-y-2 active:shadow-none transition overflow-hidden"
      >
        <div className="absolute inset-0 rounded-[2rem] ring-4 ring-white/20 pointer-events-none" />
        <div className="absolute -top-8 -left-8 w-32 h-32 rounded-full bg-white/10 blur-xl" />
        <div className="absolute -bottom-8 -right-8 w-32 h-32 rounded-full bg-white/10 blur-xl" />
        <div className="relative flex items-center justify-center gap-4">
          <div className="w-20 h-20 rounded-full bg-white/20 grid place-items-center bounce-soft">
            <Play className="w-10 h-10 fill-white" strokeWidth={0} />
          </div>
          <div className="text-left">
            <div className="font-display text-4xl font-bold tracking-tight">JOGAR</div>
            <div className="text-white/90 text-sm">Continue sua aventura</div>
          </div>
        </div>
        <div className="absolute top-3 right-4 bg-yellow-400 text-yellow-900 rounded-full px-3 py-1 font-display text-xs font-bold shadow-md">
          Fase {nextPhase}
        </div>
      </button>

      {/* Orbit */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {orbit.map((c) => {
          const Icon = c.icon;
          return (
            <button
              key={c.id}
              onClick={() => onNavigate(c.id)}
              className={`rounded-2xl bg-gradient-to-br ${c.gradient} p-4 text-white shadow-md hover:-translate-y-1 active:translate-y-0 transition`}
            >
              <div className="w-12 h-12 mx-auto rounded-xl bg-white/20 grid place-items-center">
                <Icon className="w-7 h-7" strokeWidth={2.2} />
              </div>
              <div className="mt-2 font-display text-sm font-bold">{c.label}</div>
            </button>
          );
        })}
      </div>

      {/* Final assessment */}
      <button
        disabled={!canAssess}
        onClick={onAssessment}
        className={`w-full rounded-2xl p-5 font-display font-bold text-white text-lg shadow-md transition flex items-center justify-center gap-3 ${
          canAssess
            ? "bg-gradient-to-r from-yellow-500 to-amber-600 hover:-translate-y-1"
            : "bg-muted text-muted-foreground cursor-not-allowed"
        }`}
      >
        {canAssess ? <Trophy className="w-6 h-6" /> : <Lock className="w-5 h-5" />}
        <span>
          {canAssess ? "Avaliação Final — Resgate do Tesouro" : `Avaliação travada · ${phasesDone}/3 fases`}
        </span>
      </button>

      {/* Phase summary */}
      <div>
        <h2 className="font-display text-xl font-bold mb-2">Sua Jornada</h2>
        <div className="grid grid-cols-3 gap-3">
          {[1, 2, 3].map((ph) => {
            const p = progress.find((x) => x.phase === ph);
            const info = phaseInfo[ph - 1];
            const Icon = info.icon;
            const prev = progress.find((x) => x.phase === ph - 1);
            const unlocked = ph === 1 || (prev && prev.level >= 5);
            return (
              <div key={ph} className={`card-toy text-center !p-3 ${unlocked ? "" : "opacity-50"}`}>
                <div className={`w-12 h-12 mx-auto rounded-xl bg-gradient-to-br ${info.gradient} grid place-items-center text-white shadow`}>
                  {unlocked ? <Icon className="w-6 h-6" strokeWidth={2.5} /> : <Lock className="w-5 h-5" />}
                </div>
                <div className="font-display font-bold text-sm mt-2">{info.title}</div>
                <div className="text-xs text-muted-foreground">Nível {p?.level || 1}/5</div>
                <div className="text-yellow-500 text-xs">{"★".repeat(p?.best_stars || 0) || "—"}</div>
              </div>
            );
          })}
        </div>
      </div>

      <button onClick={signOut} className="text-sm text-muted-foreground underline mx-auto block">Sair</button>
    </div>
  );
}
