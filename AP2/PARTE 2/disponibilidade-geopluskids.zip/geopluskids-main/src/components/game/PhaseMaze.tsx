import { useCallback, useEffect, useMemo, useRef, useState, type ReactElement } from "react";
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp } from "lucide-react";
import { Feedback } from "./Feedback";
import { AutoSpeak, SpeakButton } from "./Speak";

interface Props {
  level: number;
  onWin: (stars: number, xp: number) => void;
  onLoseLife: () => void;
}

type Shape = "circulo" | "quadrado" | "triangulo" | "retangulo";
const SHAPE_META: Record<Shape, { name: string; svg: (color: string) => ReactElement }> = {
  circulo:   { name: "círculo",   svg: (c) => <circle cx="50" cy="50" r="38" fill={c} /> },
  quadrado:  { name: "quadrado",  svg: (c) => <rect x="15" y="15" width="70" height="70" rx="6" fill={c} /> },
  triangulo: { name: "triângulo", svg: (c) => <polygon points="50,12 88,82 12,82" fill={c} /> },
  retangulo: { name: "retângulo", svg: (c) => <rect x="8" y="28" width="84" height="44" rx="4" fill={c} /> },
};

type CellType = "empty" | "wall" | "shape" | "spike";
type Cell = { type: CellType; shape?: Shape };

function buildMaze(level: number) {
  const size = Math.min(6 + Math.floor(level / 2), 9);
  const grid: Cell[][] = Array.from({ length: size }, () =>
    Array.from({ length: size }, () => ({ type: "empty" as CellType }))
  );

  // walls
  const wallCount = Math.floor(size * size * (0.12 + level * 0.03));
  for (let i = 0; i < wallCount; i++) {
    const x = Math.floor(Math.random() * size);
    const y = Math.floor(Math.random() * size);
    if (x === 0 && y === 0) continue;
    grid[y][x] = { type: "wall" };
  }

  // spikes (new obstacle)
  const spikeCount = Math.min(level + 1, 6);
  let placed = 0, tries = 0;
  while (placed < spikeCount && tries < 200) {
    tries++;
    const x = Math.floor(Math.random() * size);
    const y = Math.floor(Math.random() * size);
    if (grid[y][x].type === "empty" && !(x === 0 && y === 0)) {
      grid[y][x] = { type: "spike" };
      placed++;
    }
  }

  const allShapes: Shape[] = ["circulo", "quadrado", "triangulo", "retangulo"];
  const target = allShapes[Math.floor(Math.random() * allShapes.length)];
  const need = Math.min(2 + Math.floor(level / 2), 5);

  let placedCorrect = 0; tries = 0;
  while (placedCorrect < need && tries < 200) {
    tries++;
    const x = Math.floor(Math.random() * size);
    const y = Math.floor(Math.random() * size);
    if (grid[y][x].type === "empty" && !(x === 0 && y === 0)) {
      grid[y][x] = { type: "shape", shape: target };
      placedCorrect++;
    }
  }
  const distractorCount = 2 + level;
  let i = 0; tries = 0;
  while (i < distractorCount && tries < 200) {
    tries++;
    const x = Math.floor(Math.random() * size);
    const y = Math.floor(Math.random() * size);
    if (grid[y][x].type === "empty" && !(x === 0 && y === 0)) {
      const other = allShapes.filter((s) => s !== target)[Math.floor(Math.random() * 3)];
      grid[y][x] = { type: "shape", shape: other };
      i++;
    }
  }

  // enemies
  const enemyCount = Math.min(1 + level, 5);
  const enemies: { x: number; y: number; px: number; py: number; dir: "l" | "r" }[] = [];
  let j = 0; tries = 0;
  while (j < enemyCount && tries < 200) {
    tries++;
    const x = Math.floor(Math.random() * size);
    const y = Math.floor(Math.random() * size);
    if (grid[y][x].type === "empty" && Math.abs(x) + Math.abs(y) > 2) {
      enemies.push({ x, y, px: x, py: y, dir: "r" });
      j++;
    }
  }
  return { size, grid, target, need, enemies };
}

export default function PhaseMaze({ level, onWin, onLoseLife }: Props) {
  const [seed, setSeed] = useState(() => Math.random());
  const maze = useMemo(() => buildMaze(level), [level, seed]);
  const [grid, setGrid] = useState(maze.grid);
  const [enemies, setEnemies] = useState(maze.enemies);
  const [player, setPlayer] = useState({ x: 0, y: 0 });
  const [collected, setCollected] = useState(0);
  const [fb, setFb] = useState<{ kind: "ok" | "err" | null; msg: string }>({ kind: null, msg: "" });
  const [won, setWon] = useState(false);
  const wonRef = useRef(false);

  useEffect(() => {
    setGrid(maze.grid);
    setEnemies(maze.enemies);
    setPlayer({ x: 0, y: 0 });
    setCollected(0);
    setFb({ kind: null, msg: "" });
    setWon(false);
    wonRef.current = false;
  }, [maze]);

  const tryMove = useCallback((dx: number, dy: number) => {
    if (wonRef.current) return;
    setPlayer((p) => {
      const nx = p.x + dx, ny = p.y + dy;
      if (nx < 0 || ny < 0 || nx >= maze.size || ny >= maze.size) return p;
      const cell = grid[ny][nx];
      if (cell.type === "wall") return p;

      if (cell.type === "spike") {
        setFb({ kind: "err", msg: "Ai! Espinhos!" });
        onLoseLife();
        return p;
      }

      if (cell.type === "shape") {
        const ng = grid.map((r) => r.slice());
        ng[ny][nx] = { type: "empty" };
        setGrid(ng);
        if (cell.shape === maze.target) {
          setCollected((c) => {
            const nc = c + 1;
            setFb({ kind: "ok", msg: `Boa! +1 ${SHAPE_META[maze.target].name}` });
            if (nc >= maze.need) {
              wonRef.current = true;
              setWon(true);
              setTimeout(() => onWin(3, maze.need * 10 + level * 5), 700);
            }
            return nc;
          });
        } else {
          setFb({ kind: "err", msg: `Esse não era ${SHAPE_META[maze.target].name}!` });
          onLoseLife();
        }
      }

      if (enemies.some((e) => e.x === nx && e.y === ny)) {
        setFb({ kind: "err", msg: "Um fantasminha te pegou!" });
        onLoseLife();
      }

      return { x: nx, y: ny };
    });
  }, [grid, enemies, maze, onLoseLife, onWin, level]);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "ArrowUp" || e.key === "w") tryMove(0, -1);
      if (e.key === "ArrowDown" || e.key === "s") tryMove(0, 1);
      if (e.key === "ArrowLeft" || e.key === "a") tryMove(-1, 0);
      if (e.key === "ArrowRight" || e.key === "d") tryMove(1, 0);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [tryMove]);

  // enemies move (animated transitions handled via CSS)
  useEffect(() => {
    if (won) return;
    const t = setInterval(() => {
      setEnemies((es) =>
        es.map((e) => {
          const moves = [[0, 1], [0, -1], [1, 0], [-1, 0]];
          for (let k = 0; k < 6; k++) {
            const [dx, dy] = moves[Math.floor(Math.random() * 4)];
            const nx = e.x + dx, ny = e.y + dy;
            if (nx >= 0 && ny >= 0 && nx < maze.size && ny < maze.size && grid[ny][nx].type !== "wall" && grid[ny][nx].type !== "spike") {
              return { x: nx, y: ny, px: e.x, py: e.y, dir: (dx > 0 ? "r" : dx < 0 ? "l" : e.dir) as "l" | "r" };
            }
          }
          return e;
        })
      );
    }, Math.max(650, 1300 - level * 130));
    return () => clearInterval(t);
  }, [grid, maze.size, level, won]);

  useEffect(() => {
    if (enemies.some((e) => e.x === player.x && e.y === player.y) && !wonRef.current) {
      setFb({ kind: "err", msg: "Um fantasma te encostou!" });
      onLoseLife();
    }
  }, [enemies, player, onLoseLife]);

  const remaining = maze.need - collected;
  const instr = `Pegue ${remaining} ${SHAPE_META[maze.target].name}${remaining > 1 ? "s" : ""}.`;
  const cellPct = 100 / maze.size;

  return (
    <section className="grid gap-3">
      <AutoSpeak text={instr} />
      <div className="card-toy !py-3">
        <div className="flex items-center justify-between mb-1">
          <span className="text-xs font-display font-bold text-muted-foreground">Nível {level} · {collected}/{maze.need}</span>
          <button onClick={() => setSeed(Math.random())} className="text-xs underline text-muted-foreground">Sortear novo</button>
        </div>
        <div className="flex items-center gap-2">
          <svg viewBox="0 0 100 100" width="38" height="38" className="text-primary">{SHAPE_META[maze.target].svg("currentColor")}</svg>
          <h2 className="font-display text-lg font-bold flex-1">{instr}</h2>
          <SpeakButton text={instr} />
        </div>
      </div>

      <div
        className="mx-auto relative rounded-3xl p-3 shadow-soft"
        style={{
          width: "min(100%, 460px)",
          background: "linear-gradient(135deg, #1e293b, #334155)",
        }}
      >
        <div
          className="relative grid gap-1 rounded-2xl overflow-hidden"
          style={{
            gridTemplateColumns: `repeat(${maze.size}, minmax(0, 1fr))`,
            aspectRatio: "1 / 1",
          }}
        >
          {grid.flatMap((row, y) =>
            row.map((cell, x) => (
              <div
                key={`${x}-${y}`}
                className={`relative rounded-md ${
                  cell.type === "wall"
                    ? "bg-slate-900 shadow-inner"
                    : "bg-gradient-to-br from-slate-100 to-slate-200"
                }`}
              >
                {cell.type === "shape" && cell.shape && (
                  <svg viewBox="0 0 100 100" className="absolute inset-1 w-[calc(100%-0.5rem)] h-[calc(100%-0.5rem)] float">
                    {SHAPE_META[cell.shape].svg(cell.shape === maze.target ? "#10b981" : "#f59e0b")}
                  </svg>
                )}
                {cell.type === "spike" && (
                  <svg viewBox="0 0 100 100" className="absolute inset-0 w-full h-full">
                    <polygon points="10,90 25,40 40,90" fill="#94a3b8" />
                    <polygon points="35,90 50,30 65,90" fill="#cbd5e1" />
                    <polygon points="60,90 75,40 90,90" fill="#94a3b8" />
                  </svg>
                )}
              </div>
            ))
          )}

          {/* Player overlay */}
          <div
            className="absolute pointer-events-none"
            style={{
              width: `${cellPct}%`,
              height: `${cellPct}%`,
              left: `${player.x * cellPct}%`,
              top: `${player.y * cellPct}%`,
              transition: "left 180ms cubic-bezier(0.34, 1.56, 0.64, 1), top 180ms cubic-bezier(0.34, 1.56, 0.64, 1)",
            }}
          >
            <PlayerSprite />
          </div>

          {/* Enemies */}
          {enemies.map((e, idx) => (
            <div
              key={idx}
              className="absolute pointer-events-none"
              style={{
                width: `${cellPct}%`,
                height: `${cellPct}%`,
                left: `${e.x * cellPct}%`,
                top: `${e.y * cellPct}%`,
                transition: "left 350ms ease-in-out, top 350ms ease-in-out",
              }}
            >
              <GhostSprite flip={e.dir === "l"} />
            </div>
          ))}
        </div>
      </div>

      <div className="mx-auto grid grid-cols-3 gap-2 max-w-[220px]">
        <span />
        <button className="btn-toy btn-secondary !py-3" onClick={() => tryMove(0, -1)} aria-label="cima"><ArrowUp /></button>
        <span />
        <button className="btn-toy btn-secondary !py-3" onClick={() => tryMove(-1, 0)} aria-label="esquerda"><ArrowLeft /></button>
        <span />
        <button className="btn-toy btn-secondary !py-3" onClick={() => tryMove(1, 0)} aria-label="direita"><ArrowRight /></button>
        <span />
        <button className="btn-toy btn-secondary !py-3" onClick={() => tryMove(0, 1)} aria-label="baixo"><ArrowDown /></button>
        <span />
      </div>

      <Feedback kind={fb.kind} message={fb.msg} />
    </section>
  );
}

function PlayerSprite() {
  return (
    <div className="relative w-full h-full grid place-items-center">
      <svg viewBox="0 0 64 64" className="w-[78%] h-[78%] bounce-soft drop-shadow-md">
        <circle cx="32" cy="32" r="26" fill="#fbbf24" stroke="#b45309" strokeWidth="2.5" />
        <circle cx="24" cy="28" r="4" fill="#1f2937" />
        <circle cx="40" cy="28" r="4" fill="#1f2937" />
        <circle cx="25" cy="27" r="1.5" fill="#fff" />
        <circle cx="41" cy="27" r="1.5" fill="#fff" />
        <path d="M22 40 Q32 48 42 40" stroke="#1f2937" strokeWidth="2.5" fill="none" strokeLinecap="round" />
      </svg>
    </div>
  );
}

function GhostSprite({ flip }: { flip: boolean }) {
  return (
    <div className="relative w-full h-full grid place-items-center" style={{ transform: flip ? "scaleX(-1)" : undefined }}>
      <svg viewBox="0 0 64 64" className="w-[80%] h-[80%] drop-shadow-md" style={{ animation: "ghostFloat 0.9s ease-in-out infinite" }}>
        <path
          d="M10 32 Q10 12 32 12 Q54 12 54 32 L54 54 L48 48 L42 54 L36 48 L30 54 L24 48 L18 54 L12 48 L10 54 Z"
          fill="#e0e7ff"
          stroke="#6366f1"
          strokeWidth="2"
        />
        <ellipse cx="24" cy="28" rx="3.5" ry="5" fill="#1e1b4b" />
        <ellipse cx="40" cy="28" rx="3.5" ry="5" fill="#1e1b4b" />
        <ellipse cx="25" cy="27" rx="1" ry="1.5" fill="#fff" />
        <ellipse cx="41" cy="27" rx="1" ry="1.5" fill="#fff" />
        <path d="M26 40 Q32 44 38 40" stroke="#6366f1" strokeWidth="1.5" fill="none" />
      </svg>
    </div>
  );
}
