// Realistic-ish 3D-looking geometric solids in SVG (no emojis).
export type SolidKey = "esfera" | "cilindro" | "cone" | "cubo" | "piramide";

export const SOLID_INFO: Record<SolidKey, { name: string; desc: string }> = {
  esfera: { name: "Esfera", desc: "Redonda, rola para todos os lados." },
  cilindro: { name: "Cilindro", desc: "Duas tampinhas redondas." },
  cone: { name: "Cone", desc: "Tem uma pontinha em cima." },
  cubo: { name: "Cubo", desc: "Seis quadrados iguais." },
  piramide: { name: "Pirâmide", desc: "Base quadrada, ponta em cima." },
};

export function SolidSVG({ kind, size = 90, color = "#60a5fa" }: { kind: SolidKey; size?: number; color?: string }) {
  const w = size, h = size;
  const dark = shade(color, -25);
  const light = shade(color, 25);
  switch (kind) {
    case "esfera":
      return (
        <svg viewBox="0 0 100 100" width={w} height={h}>
          <defs>
            <radialGradient id="sph" cx="35%" cy="30%" r="70%">
              <stop offset="0%" stopColor={light} />
              <stop offset="60%" stopColor={color} />
              <stop offset="100%" stopColor={dark} />
            </radialGradient>
          </defs>
          <circle cx="50" cy="52" r="40" fill="url(#sph)" />
          <ellipse cx="50" cy="92" rx="30" ry="4" fill="#000" opacity="0.18" />
        </svg>
      );
    case "cilindro":
      return (
        <svg viewBox="0 0 100 100" width={w} height={h}>
          <defs>
            <linearGradient id="cyl" x1="0" x2="1">
              <stop offset="0%" stopColor={dark} />
              <stop offset="50%" stopColor={light} />
              <stop offset="100%" stopColor={dark} />
            </linearGradient>
          </defs>
          <rect x="22" y="22" width="56" height="60" fill="url(#cyl)" />
          <ellipse cx="50" cy="22" rx="28" ry="8" fill={light} stroke={dark} />
          <ellipse cx="50" cy="82" rx="28" ry="8" fill={dark} />
        </svg>
      );
    case "cone":
      return (
        <svg viewBox="0 0 100 100" width={w} height={h}>
          <defs>
            <linearGradient id="con" x1="0" x2="1">
              <stop offset="0%" stopColor={dark} />
              <stop offset="50%" stopColor={light} />
              <stop offset="100%" stopColor={dark} />
            </linearGradient>
          </defs>
          <path d="M50,8 L82,82 L18,82 Z" fill="url(#con)" />
          <ellipse cx="50" cy="82" rx="32" ry="8" fill={dark} />
        </svg>
      );
    case "cubo":
      return (
        <svg viewBox="0 0 100 100" width={w} height={h}>
          <polygon points="20,35 50,20 80,35 80,80 50,95 20,80" fill={color} />
          <polygon points="20,35 50,20 50,55 20,70" fill={light} />
          <polygon points="50,20 80,35 80,70 50,55" fill={dark} />
          <polygon points="20,70 50,55 80,70 50,85" fill={shade(color, 10)} opacity="0.6" />
        </svg>
      );
    case "piramide":
      return (
        <svg viewBox="0 0 100 100" width={w} height={h}>
          <polygon points="50,10 90,80 50,68" fill={dark} />
          <polygon points="50,10 10,80 50,68" fill={light} />
          <polygon points="10,80 50,68 90,80 50,92" fill={color} />
        </svg>
      );
  }
}

function shade(hex: string, p: number) {
  const n = parseInt(hex.replace("#", ""), 16);
  const a = Math.round(2.55 * p);
  const r = Math.max(0, Math.min(255, (n >> 16) + a));
  const g = Math.max(0, Math.min(255, ((n >> 8) & 0xff) + a));
  const b = Math.max(0, Math.min(255, (n & 0xff) + a));
  return "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
}
