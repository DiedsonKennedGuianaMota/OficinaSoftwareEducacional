export default function GameOver({ onRetry, onHome }: { onRetry: () => void; onHome: () => void }) {
  return (
    <div className="card-toy text-center pop-in">
      <div className="text-6xl">💔</div>
      <h2 className="font-display text-3xl font-bold mt-2">Suas vidas acabaram!</h2>
      <p className="text-muted-foreground mt-1">Sem problema. Cada erro ensina algo novo.</p>
      <div className="mt-5 flex justify-center gap-2">
        <button onClick={onRetry} className="btn-toy btn-primary">🔁 Tentar de novo</button>
        <button onClick={onHome} className="btn-toy btn-secondary">🏠 Voltar ao início</button>
      </div>
    </div>
  );
}
