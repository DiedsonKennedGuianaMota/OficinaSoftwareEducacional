import { useProfile } from "@/lib/game/ProfileContext";
import { THEMES } from "@/lib/game/constants";
import { toast } from "sonner";

export default function ThemeSelector({ onBack }: { onBack: () => void }) {
  const { profile, setTheme, addUnlocked } = useProfile();
  if (!profile) return null;

  const pick = async (id: string, price: number) => {
    const key = `theme:${id}`;
    if (price === 0 || profile.unlocked.includes(key)) {
      setTheme(id as never);
      return;
    }
    if (profile.xp < price) return toast.error(`Faltam ${price - profile.xp} XP.`);
    if (!confirm(`Comprar tema por ${price} XP?`)) return;
    await addUnlocked([key], price);
    setTheme(id as never);
    toast.success("Tema desbloqueado! 🎨");
  };

  return (
    <div>
      <button onClick={onBack} className="btn-toy btn-secondary mb-4">← Voltar</button>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
        {THEMES.map((t) => {
          const owned = t.price === 0 || profile.unlocked.includes(`theme:${t.id}`);
          const active = profile.theme === t.id;
          return (
            <button
              key={t.id}
              onClick={() => pick(t.id, t.price)}
              className={`card-toy flex flex-col items-center gap-2 transition ${active ? "ring-4 ring-primary" : ""}`}
            >
              <div className="text-5xl">{t.emoji}</div>
              <div className="font-display font-bold">{t.name}</div>
              {!owned && <div className="text-xs">🔒 ⭐{t.price}</div>}
              {active && <div className="text-xs text-success font-bold">✓ Em uso</div>}
            </button>
          );
        })}
      </div>
    </div>
  );
}
