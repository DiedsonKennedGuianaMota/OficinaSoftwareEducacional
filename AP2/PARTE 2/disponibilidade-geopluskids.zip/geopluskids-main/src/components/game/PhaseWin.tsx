export default function PhaseWin({
  phase, level, stars, xpGained, onNext, onHome,
}: {
  phase: number; level: number; stars: number; xpGained: number;
  onNext: () => void; onHome: () => void;
}) {
  const titles = ["Localização", "Sólidos Geométricos", "Labirinto das Formas"];
  const isLastLevel = level >= 5;
  return (
    <div className="card-toy text-center relative overflow-hidden pop-in">
      {/* Confetti contained within card */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        {Array.from({ length: 18 }).map((_, i) => (
          <span
            key={i}
            className="absolute block h-2 w-2 rounded-sm"
            style={{
              left: `${(i * 53) % 100}%`,
              top: `-10%`,
              background: ["#f97316", "#eab308", "#22c55e", "#3b82f6", "#ec4899"][i % 5],
              animation: `confettiFall ${2 + (i % 4) * 0.3}s ${i * 0.08}s ease-in forwards`,
              transform: `rotate(${i * 23}deg)`,
            }}
          />
        ))}
      </div>

      <div className="relative">
        <div className="mx-auto w-24 h-24 rounded-full bg-gradient-to-br from-yellow-300 to-amber-500 grid place-items-center shadow-lg bounce-soft">
          <svg viewBox="0 0 24 24" className="w-14 h-14 text-white" fill="currentColor">
            <path d="M12 2l2.39 4.84 5.34.78-3.86 3.76.91 5.31L12 14.77l-4.78 2.52.91-5.31L4.27 8.22l5.34-.78z" />
          </svg>
        </div>
        <h2 className="font-display text-3xl font-bold mt-3">Muito bem!</h2>
        <p className="text-muted-foreground">Fase {phase} — {titles[phase - 1]} · Nível {level}</p>

        {/* Stars row contained */}
        <div className="my-4 flex justify-center gap-2">
          {[1, 2, 3].map((i) => (
            <svg
              key={i}
              viewBox="0 0 24 24"
              className={`w-10 h-10 transition-all ${i <= stars ? "text-yellow-400 drop-shadow" : "text-muted"}`}
              fill="currentColor"
              style={{ animation: i <= stars ? `popIn 0.4s ${i * 0.15}s both` : undefined }}
            >
              <path d="M12 2l2.39 4.84 5.34.78-3.86 3.76.91 5.31L12 14.77l-4.78 2.52.91-5.31L4.27 8.22l5.34-.78z" />
            </svg>
          ))}
        </div>

        <div className="inline-block rounded-full bg-gradient-to-r from-emerald-400 to-teal-500 px-4 py-1 text-white font-display font-bold">
          +{xpGained} XP
        </div>

        <div className="mt-5 flex justify-center gap-2 flex-wrap">
          <button onClick={onNext} className="btn-toy btn-primary">
            {isLastLevel && phase < 3 ? "Próxima fase" : isLastLevel ? "Voltar ao início" : "Próximo nível"}
          </button>
          <button onClick={onHome} className="btn-toy btn-secondary">Início</button>
        </div>
      </div>
    </div>
  );
}
