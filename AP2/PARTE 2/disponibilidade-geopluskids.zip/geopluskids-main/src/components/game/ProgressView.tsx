import { useEffect, useState } from "react";
import { useProfile } from "@/lib/game/ProfileContext";
import { loadProgress } from "@/lib/game/profile";

export default function ProgressView({ onBack }: { onBack: () => void }) {
  const { profile } = useProfile();
  const [rows, setRows] = useState<{ phase: number; level: number; best_stars: number; plays: number }[]>([]);
  useEffect(() => {
    if (profile) loadProgress(profile.id).then((r) => setRows(r as never));
  }, [profile]);
  const titles = ["Localização", "Sólidos", "Labirinto das Formas"];
  return (
    <div>
      <button onClick={onBack} className="btn-toy btn-secondary mb-4">← Voltar</button>
      <div className="card-toy">
        <h2 className="font-display text-2xl font-bold mb-4">📊 Meu Progresso</h2>
        <div className="space-y-3">
          {[1, 2, 3].map((ph) => {
            const r = rows.find((x) => x.phase === ph);
            return (
              <div key={ph} className="flex items-center gap-3 rounded-2xl bg-muted p-3">
                <div className="text-3xl">{["🧭", "📦", "🌀"][ph - 1]}</div>
                <div className="flex-1">
                  <div className="font-display font-bold">Fase {ph}: {titles[ph - 1]}</div>
                  <div className="text-sm">Nível {r?.level || 1} • Jogou {r?.plays || 0}x</div>
                </div>
                <div className="text-2xl">{"⭐".repeat(r?.best_stars || 0)}</div>
              </div>
            );
          })}
        </div>
        <div className="mt-4 text-center text-lg">
          Total: <strong>⭐ {profile?.xp || 0} XP</strong>
        </div>
      </div>
    </div>
  );
}
