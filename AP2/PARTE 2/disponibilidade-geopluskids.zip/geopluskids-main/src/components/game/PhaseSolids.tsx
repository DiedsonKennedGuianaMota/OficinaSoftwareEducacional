import { useEffect, useMemo, useRef, useState } from "react";
import { Feedback } from "./Feedback";
import { AutoSpeak, SpeakButton } from "./Speak";
import { SolidSVG, SOLID_INFO, type SolidKey } from "./SolidSVG";
import { Timer } from "lucide-react";

interface Props {
  level: number;
  onWin: (stars: number, xp: number) => void;
  onLoseLife: () => void;
}

// NOTE: "Livro" was removed — a book is a paralelepípedo (rectangular block),
// NOT a cube. We only keep objects that are clearly cube-like.
const OBJECTS: { id: string; emoji: string; label: string; solid: SolidKey }[] = [
  { id: "bola", emoji: "⚽", label: "Bola", solid: "esfera" },
  { id: "laranja", emoji: "🍊", label: "Laranja", solid: "esfera" },
  { id: "globo", emoji: "🌍", label: "Globo", solid: "esfera" },
  { id: "melancia", emoji: "🍉", label: "Melancia", solid: "esfera" },
  { id: "lata", emoji: "🥫", label: "Lata", solid: "cilindro" },
  { id: "copo", emoji: "🥤", label: "Copo", solid: "cilindro" },
  { id: "rolo", emoji: "🧻", label: "Rolo", solid: "cilindro" },
  { id: "vela", emoji: "🕯️", label: "Vela", solid: "cilindro" },
  { id: "chapeu", emoji: "🎉", label: "Chapéu", solid: "cone" },
  { id: "sorvete", emoji: "🍦", label: "Sorvete", solid: "cone" },
  { id: "arvorenatal", emoji: "🎄", label: "Pinheiro", solid: "cone" },
  { id: "caixa", emoji: "📦", label: "Caixa", solid: "cubo" },
  { id: "dado", emoji: "🎲", label: "Dado", solid: "cubo" },
  { id: "presente", emoji: "🎁", label: "Presente", solid: "cubo" },
  { id: "piramide", emoji: "🔺", label: "Pirâmide", solid: "piramide" },
];

const SOLID_COLORS: Record<SolidKey, string> = {
  esfera: "#60a5fa", cilindro: "#34d399", cone: "#f472b6", cubo: "#fbbf24", piramide: "#a78bfa",
};

function shuffle<T>(arr: T[]) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function buildRound(level: number, seed: number) {
  const solidCount = Math.min(2 + level, 5);
  const allSolids: SolidKey[] = ["esfera", "cilindro", "cone", "cubo", "piramide"];
  const solids = shuffle(allSolids).slice(0, solidCount);
  const objCount = Math.min(3 + level, 8);
  const candidates = OBJECTS.filter((o) => solids.includes(o.solid));
  const objs = shuffle(candidates).slice(0, objCount);
  void seed;
  return { solids, objects: objs };
}

// Higher level = less time per object. Level 1 is generous.
function timeForLevel(level: number, objCount: number) {
  const perObj = Math.max(4, 9 - level); // 8s..4s per object
  return perObj * objCount;
}

export default function PhaseSolids({ level, onWin, onLoseLife }: Props) {
  const [seed, setSeed] = useState(() => Math.floor(Math.random() * 1000));
  const round = useMemo(() => buildRound(level, seed), [level, seed]);
  const [placed, setPlaced] = useState<Record<string, SolidKey>>({});
  const [stars, setStars] = useState(0);
  const [errors, setErrors] = useState(0);
  const [fb, setFb] = useState<{ kind: "ok" | "err" | null; msg: string }>({ kind: null, msg: "" });
  const totalTime = timeForLevel(level, round.objects.length);
  const [time, setTime] = useState(totalTime);
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    setPlaced({}); setStars(0); setErrors(0); setFb({ kind: null, msg: "" });
    setTime(timeForLevel(level, round.objects.length));
  }, [seed, level, round.objects.length]);

  // Countdown — starts at level >= 2 so the first level stays bem tranquilo.
  useEffect(() => {
    if (level < 2) return;
    if (timerRef.current) window.clearInterval(timerRef.current);
    timerRef.current = window.setInterval(() => {
      setTime((t) => {
        if (t <= 1) {
          window.clearInterval(timerRef.current!);
          onLoseLife();
          setFb({ kind: "err", msg: "Acabou o tempo! Tente de novo." });
          // re-roll round so it's not the same again
          setTimeout(() => setSeed(Math.random() * 1000), 700);
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => { if (timerRef.current) window.clearInterval(timerRef.current); };
  }, [seed, level, onLoseLife]);

  const remaining = round.objects.filter((o) => !placed[o.id]);

  const drop = (target: SolidKey, id: string) => {
    const obj = round.objects.find((o) => o.id === id);
    if (!obj) return;
    if (obj.solid === target) {
      setPlaced((p) => ({ ...p, [id]: target }));
      setStars((s) => s + 1);
      setFb({ kind: "ok", msg: `${obj.label} é um ${SOLID_INFO[target].name.toLowerCase()}!` });
      if (remaining.length - 1 === 0) {
        if (timerRef.current) window.clearInterval(timerRef.current);
        const bonus = errors === 0 ? 2 : 0;
        const timeBonus = level >= 2 && time > totalTime / 2 ? 1 : 0;
        const totalStars = stars + 1 + bonus + timeBonus;
        setTimeout(() => onWin(totalStars, totalStars * 5 + level * 10), 900);
      }
    } else {
      setErrors((e) => e + 1);
      onLoseLife();
      setFb({ kind: "err", msg: `Esse não. Olhe a forma!` });
    }
  };

  const instr = "Arraste cada objeto até o sólido certo.";
  const timePct = Math.max(0, (time / totalTime) * 100);

  return (
    <section className="grid gap-4">
      <AutoSpeak text={instr} />
      <div className="card-toy">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-muted-foreground">Nível {level}</span>
          <button onClick={() => setSeed(Math.random() * 1000)} className="text-xs underline">🎲 outro</button>
        </div>
        <div className="flex items-center gap-2">
          <h2 className="font-display text-xl font-bold">{instr}</h2>
          <SpeakButton text={instr} />
        </div>

        {level >= 2 && (
          <div className="mt-3">
            <div className="flex items-center gap-2 text-xs font-bold mb-1">
              <Timer className="w-4 h-4" /> {time}s
            </div>
            <div className="h-3 rounded-full bg-muted overflow-hidden">
              <div
                className={`h-full transition-all ${timePct > 50 ? "bg-emerald-400" : timePct > 25 ? "bg-amber-400" : "bg-rose-500 animate-pulse"}`}
                style={{ width: `${timePct}%` }}
              />
            </div>
          </div>
        )}
      </div>

      <div className="grid gap-3" style={{ gridTemplateColumns: `repeat(${round.solids.length}, minmax(0, 1fr))` }}>
        {round.solids.map((s) => {
          const inside = round.objects.filter((o) => placed[o.id] === s);
          return (
            <div
              key={s}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => { e.preventDefault(); const id = e.dataTransfer.getData("text/plain"); if (id) drop(s, id); }}
              className="card-toy min-h-44 border-2 border-dashed text-center"
            >
              <SolidSVG kind={s} color={SOLID_COLORS[s]} size={70} />
              <div className="font-display font-bold">{SOLID_INFO[s].name}</div>
              <div className="text-xs text-muted-foreground">{SOLID_INFO[s].desc}</div>
              <div className="mt-2 flex flex-wrap justify-center gap-1 text-2xl">
                {inside.map((o) => (<span key={o.id} className="pop-in">{o.emoji}</span>))}
              </div>
            </div>
          );
        })}
      </div>

      <div className="card-toy">
        <div className="mb-2 font-display font-bold">Objetos:</div>
        <div className="flex flex-wrap gap-2">
          {remaining.map((o) => (
            <button
              key={o.id}
              draggable
              onDragStart={(e) => e.dataTransfer.setData("text/plain", o.id)}
              onClick={() => {/* tap-to-pick fallback could be added */}}
              className="float flex flex-col items-center gap-1 rounded-2xl bg-muted p-3 hover:scale-105 active:scale-95 cursor-grab"
            >
              <span className="text-4xl">{o.emoji}</span>
              <span className="text-xs font-semibold">{o.label}</span>
            </button>
          ))}
          {remaining.length === 0 && <div className="text-success font-bold">Tudo certo! 🎉</div>}
        </div>
        <div className="mt-3"><Feedback kind={fb.kind} message={fb.msg} /></div>
      </div>
    </section>
  );
}

