import { Heart, Settings, Home } from "lucide-react";
import { useProfile } from "@/lib/game/ProfileContext";

export default function Hud({
  lives, maxLives, onHome, onOpenA11y, showInGame,
}: {
  lives: number;
  maxLives: number;
  onHome: () => void;
  onOpenA11y: () => void;
  showInGame: boolean;
}) {
  const { profile } = useProfile();
  return (
    <header className="sticky top-0 z-30 border-b-2 border-border bg-card/90 backdrop-blur">
      <div className="mx-auto flex max-w-5xl items-center gap-3 px-3 py-2">
        <button onClick={onHome} className="btn-toy btn-secondary !py-1 !px-2" aria-label="Início">
          <Home className="h-4 w-4" />
        </button>
        <div className="font-display font-bold">🎮 Aventura Geométrica</div>
        <div className="flex-1" />
        {showInGame && (
          <div className="flex items-center gap-1" aria-label={`Vidas: ${lives}`}>
            {Array.from({ length: maxLives }).map((_, i) => (
              <Heart key={i} className={`h-5 w-5 ${i < lives ? "fill-red-500 text-red-500" : "text-muted-foreground/30"}`} />
            ))}
          </div>
        )}
        {profile && <div className="text-sm font-bold">⭐ {profile.xp}</div>}
        <button onClick={onOpenA11y} className="btn-toy btn-secondary !py-1 !px-2" aria-label="Acessibilidade">
          <Settings className="h-4 w-4" />
        </button>
      </div>
    </header>
  );
}
