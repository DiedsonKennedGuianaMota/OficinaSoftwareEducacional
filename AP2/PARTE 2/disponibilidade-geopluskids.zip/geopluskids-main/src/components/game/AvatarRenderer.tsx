import type { AvatarConfig } from "@/lib/game/constants";

/**
 * Stylized realistic kid avatar. Head ellipse: cx=100, cy=98, rx=54, ry=60.
 * Top of head ≈ y=38; jaw ≈ y=158. Hair paths are tuned to wrap that shape.
 */
export function AvatarRenderer({ a, size = 160, animated = true }: { a: AvatarConfig; size?: number; animated?: boolean }) {
  return (
    <div
      className="inline-block"
      style={{
        width: size,
        height: size,
        animation: animated ? "breathe 3.2s ease-in-out infinite" : undefined,
      }}
    >
      <svg viewBox="0 0 200 230" width={size} height={size} className="drop-shadow-lg">
        <defs>
          <radialGradient id="cheekGrad" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#ff7a90" stopOpacity="0.75" />
            <stop offset="100%" stopColor="#ff7a90" stopOpacity="0" />
          </radialGradient>
          <linearGradient id="shirtShade" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={shade(a.outfitColor, 6)} />
            <stop offset="60%" stopColor={a.outfitColor} />
            <stop offset="100%" stopColor={shade(a.outfitColor, -22)} />
          </linearGradient>
          <radialGradient id="headShade" cx="40%" cy="35%" r="70%">
            <stop offset="0%" stopColor={shade(a.skin, 12)} />
            <stop offset="70%" stopColor={a.skin} />
            <stop offset="100%" stopColor={shade(a.skin, -10)} />
          </radialGradient>
          <linearGradient id="hairShade" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={shade(a.hairColor, 14)} />
            <stop offset="100%" stopColor={shade(a.hairColor, -16)} />
          </linearGradient>
        </defs>

        {/* ground shadow */}
        <ellipse cx="100" cy="222" rx="58" ry="5" fill="#000" opacity="0.14" />

        {/* shoulders / shirt */}
        <path d="M30,218 Q30,156 100,156 Q170,156 170,218 Z" fill="url(#shirtShade)" />
        {/* collar shadow */}
        <path d="M76,156 Q100,170 124,156 L122,164 Q100,176 78,164 Z" fill={shade(a.outfitColor, -32)} opacity="0.55" />
        <Outfit kind={a.outfit} color={a.outfitColor} />

        {/* neck */}
        <path d="M86,140 Q86,160 100,162 Q114,160 114,140 Z" fill={shade(a.skin, -14)} />
        <path d="M86,148 Q100,156 114,148" stroke={shade(a.skin, -22)} strokeWidth="1" fill="none" opacity="0.5" />

        {/* ears */}
        <ellipse cx="44" cy="102" rx="9" ry="14" fill="url(#headShade)" />
        <ellipse cx="156" cy="102" rx="9" ry="14" fill="url(#headShade)" />
        <path d="M44,98 Q48,104 44,110" stroke={shade(a.skin, -22)} strokeWidth="1.3" fill="none" opacity="0.7" />
        <path d="M156,98 Q152,104 156,110" stroke={shade(a.skin, -22)} strokeWidth="1.3" fill="none" opacity="0.7" />

        {/* head */}
        <ellipse cx="100" cy="98" rx="54" ry="60" fill="url(#headShade)" />
        {/* chin definition */}
        <path d="M70,140 Q100,168 130,140" stroke={shade(a.skin, -18)} strokeWidth="1" fill="none" opacity="0.45" />

        {/* hair behind face elements */}
        <Hair style={a.hairStyle} color={a.hairColor} />

        {/* cheeks */}
        <ellipse cx="68" cy="120" rx="12" ry="8" fill="url(#cheekGrad)" />
        <ellipse cx="132" cy="120" rx="12" ry="8" fill="url(#cheekGrad)" />

        {/* brows */}
        <Brows style={a.brow} color={shade(a.hairColor, -25)} />

        {/* eyes */}
        <Eyes style={a.eye} color={a.eyeColor} animated={animated} />

        {/* nose */}
        <path d="M96,108 Q100,118 104,108" stroke={shade(a.skin, -28)} strokeWidth="1.6" fill="none" strokeLinecap="round" />
        <ellipse cx="100" cy="117" rx="3" ry="1.2" fill={shade(a.skin, -18)} opacity="0.6" />

        {/* mouth */}
        <Mouth style={a.mouth} />

        {/* face accessory */}
        <FaceAcc id={a.face} />

        {/* extra accessory */}
        <Accessory id={a.accessory} color={a.outfitColor} />
      </svg>
    </div>
  );
}

/* ---------------- HAIR — fitted to the head shape ---------------- */
function Hair({ style, color }: { style: string; color: string }) {
  const dark = shade(color, -22);
  const light = shade(color, 18);
  switch (style) {
    case "long":
      return (
        <g>
          {/* back hair */}
          <path d="M40,98 Q38,52 100,42 Q162,52 160,100 L158,170 Q156,184 138,184 L138,96 Q100,80 62,96 L62,184 Q44,184 42,170 Z" fill="url(#hairShade)" />
          {/* front cap hugging skull */}
          <path d="M52,92 Q60,46 100,42 Q140,46 148,92 Q140,76 100,72 Q60,76 52,92 Z" fill={color} />
          {/* fringe */}
          <path d="M62,80 Q80,72 96,82 Q100,78 104,82 Q120,72 138,80 Q120,90 100,86 Q80,90 62,80 Z" fill={dark} opacity="0.55" />
          {/* shine */}
          <path d="M70,62 Q82,52 96,58" stroke={light} strokeWidth="2.5" fill="none" strokeLinecap="round" opacity="0.7" />
        </g>
      );
    case "curly":
      return (
        <g>
          <g fill="url(#hairShade)">
            <circle cx="62" cy="64" r="20" />
            <circle cx="84" cy="48" r="20" />
            <circle cx="108" cy="46" r="22" />
            <circle cx="134" cy="58" r="20" />
            <circle cx="150" cy="78" r="16" />
            <circle cx="50" cy="84" r="16" />
            <circle cx="74" cy="80" r="14" />
            <circle cx="124" cy="78" r="14" />
          </g>
          <circle cx="86" cy="56" r="6" fill={light} opacity="0.6" />
        </g>
      );
    case "buzz":
      return (
        <g>
          <path d="M48,96 Q52,58 100,52 Q148,58 152,96 Q148,82 100,78 Q52,82 48,96 Z" fill={color} />
          <path d="M58,82 Q100,72 142,82" stroke={dark} strokeWidth="1" fill="none" opacity="0.4" />
        </g>
      );
    case "mohawk":
      return (
        <g>
          <path d="M50,96 Q60,82 100,78 Q140,82 150,96 Q140,88 100,86 Q60,88 50,96 Z" fill={dark} />
          <path d="M86,26 Q100,4 114,26 L118,86 L82,86 Z" fill="url(#hairShade)" />
          <path d="M100,12 L100,80" stroke={light} strokeWidth="2" opacity="0.6" />
        </g>
      );
    case "ponytail":
      return (
        <g>
          <path d="M48,96 Q52,52 100,46 Q148,52 152,96 Q148,80 100,76 Q52,80 48,96 Z" fill="url(#hairShade)" />
          {/* ponytail behind */}
          <path d="M150,86 Q176,108 174,142 Q168,156 158,148 Q160,124 148,100 Z" fill={color} />
          <ellipse cx="151" cy="92" rx="6" ry="4" fill={dark} />
          {/* bangs */}
          <path d="M62,86 Q78,76 96,86 Q100,82 104,86 Q120,76 138,86 Q120,94 100,90 Q80,94 62,86 Z" fill={dark} opacity="0.5" />
        </g>
      );
    case "afro":
      return (
        <g>
          <circle cx="100" cy="68" r="56" fill="url(#hairShade)" />
          <circle cx="74" cy="60" r="14" fill={dark} opacity="0.4" />
          <circle cx="126" cy="64" r="12" fill={dark} opacity="0.4" />
          <circle cx="90" cy="42" r="8" fill={light} opacity="0.5" />
        </g>
      );
    case "bun":
      return (
        <g>
          <path d="M48,96 Q52,54 100,48 Q148,54 152,96 Q148,82 100,78 Q52,82 48,96 Z" fill="url(#hairShade)" />
          <circle cx="100" cy="34" r="20" fill={color} />
          <circle cx="100" cy="34" r="13" fill={dark} opacity="0.45" />
          <circle cx="94" cy="28" r="3" fill={light} opacity="0.7" />
        </g>
      );
    default: // short
      return (
        <g>
          <path d="M48,94 Q56,46 100,42 Q144,46 152,94 Q144,76 100,72 Q56,76 48,94 Z" fill="url(#hairShade)" />
          <path d="M64,76 Q82,64 100,72 Q118,64 136,76" stroke={dark} strokeWidth="2" fill="none" opacity="0.55" />
          <path d="M72,58 Q86,50 100,54" stroke={light} strokeWidth="2.2" fill="none" opacity="0.7" strokeLinecap="round" />
        </g>
      );
  }
}

/* ---------------- BROWS — sit above the eyes (y≈100) ---------------- */
function Brows({ style, color }: { style: string; color: string }) {
  const base = { stroke: color, strokeLinecap: "round" as const, fill: "none" };
  switch (style) {
    case "thick":
      return (
        <g {...base} strokeWidth="6">
          <path d="M66,88 Q80,82 94,86" />
          <path d="M106,86 Q120,82 134,88" />
        </g>
      );
    case "thin":
      return (
        <g {...base} strokeWidth="2.2">
          <path d="M66,90 Q80,86 94,88" />
          <path d="M106,88 Q120,86 134,90" />
        </g>
      );
    case "raised":
      return (
        <g {...base} strokeWidth="3.8">
          <path d="M66,92 Q80,78 94,86" />
          <path d="M106,86 Q120,78 134,92" />
        </g>
      );
    case "angry":
      return (
        <g {...base} strokeWidth="4.5">
          <path d="M66,82 L94,92" />
          <path d="M106,92 L134,82" />
        </g>
      );
    default:
      return (
        <g {...base} strokeWidth="4">
          <path d="M66,90 Q80,84 94,88" />
          <path d="M106,88 Q120,84 134,90" />
        </g>
      );
  }
}

/* ---------------- EYES ---------------- */
function Eyes({ style, color, animated }: { style: string; color: string; animated: boolean }) {
  const lashStyle = { stroke: "#1f2937", strokeWidth: 1.6, strokeLinecap: "round" as const, fill: "none" };
  switch (style) {
    case "happy":
      return (
        <g stroke="#1f2937" strokeWidth="3.5" fill="none" strokeLinecap="round">
          <path d="M68,104 Q80,96 92,104" />
          <path d="M108,104 Q120,96 132,104" />
        </g>
      );
    case "sleepy":
      return (
        <g>
          <path d="M66,104 Q80,108 94,104" stroke="#1f2937" strokeWidth="3" fill="none" strokeLinecap="round" />
          <path d="M106,104 Q120,108 134,104" stroke="#1f2937" strokeWidth="3" fill="none" strokeLinecap="round" />
          <path d="M68,100 L92,100 M108,100 L132,100" stroke="#1f2937" strokeWidth="1.5" />
        </g>
      );
    case "star":
      return <g fill={color}><Star cx={80} cy={104} /><Star cx={120} cy={104} /></g>;
    case "heart":
      return <g fill="#ef4444"><Heart cx={80} cy={104} /><Heart cx={120} cy={104} /></g>;
    default:
      return (
        <g style={{ transformOrigin: "100px 104px", animation: animated ? "blink 4.5s infinite" : undefined }}>
          {/* whites */}
          <ellipse cx="80" cy="104" rx="9" ry="10" fill="#fff" stroke="#1f2937" strokeWidth="1.2" />
          <ellipse cx="120" cy="104" rx="9" ry="10" fill="#fff" stroke="#1f2937" strokeWidth="1.2" />
          {/* iris */}
          <circle cx="81" cy="105" r="5.5" fill={color} />
          <circle cx="121" cy="105" r="5.5" fill={color} />
          {/* pupil */}
          <circle cx="81" cy="105" r="2.6" fill="#0b1220" />
          <circle cx="121" cy="105" r="2.6" fill="#0b1220" />
          {/* shine */}
          <circle cx="78.5" cy="102" r="1.6" fill="#fff" />
          <circle cx="118.5" cy="102" r="1.6" fill="#fff" />
          {/* lashes */}
          <path d="M71,96 L69,92 M76,94 L75,90 M81,93 L81,89 M86,94 L87,90 M91,96 L93,92" {...lashStyle} />
          <path d="M111,96 L109,92 M116,94 L115,90 M121,93 L121,89 M126,94 L127,90 M131,96 L133,92" {...lashStyle} />
        </g>
      );
  }
}

function Star({ cx, cy }: { cx: number; cy: number }) {
  const pts = [];
  for (let i = 0; i < 10; i++) {
    const r = i % 2 === 0 ? 9 : 3.6;
    const a = (Math.PI / 5) * i - Math.PI / 2;
    pts.push(`${cx + r * Math.cos(a)},${cy + r * Math.sin(a)}`);
  }
  return <polygon points={pts.join(" ")} />;
}
function Heart({ cx, cy }: { cx: number; cy: number }) {
  return <path d={`M${cx},${cy + 6} C${cx - 10},${cy - 3} ${cx - 10},${cy - 13} ${cx},${cy - 5} C${cx + 10},${cy - 13} ${cx + 10},${cy - 3} ${cx},${cy + 6} Z`} />;
}

/* ---------------- MOUTH ---------------- */
function Mouth({ style }: { style: string }) {
  switch (style) {
    case "grin":
      return (
        <g>
          <path d="M76,128 Q100,152 124,128 Q124,134 100,140 Q76,134 76,128 Z" fill="#7a1f1f" />
          <path d="M82,131 Q100,144 118,131 Q100,135 82,131 Z" fill="#fff" />
          <line x1="100" y1="131" x2="100" y2="142" stroke="#e5e7eb" strokeWidth="0.8" />
        </g>
      );
    case "tongue":
      return (
        <g>
          <path d="M78,128 Q100,148 122,128 Z" fill="#7a1f1f" />
          <ellipse cx="100" cy="140" rx="11" ry="7" fill="#ff7a90" />
          <line x1="100" y1="135" x2="100" y2="146" stroke="#c1466b" strokeWidth="1" />
        </g>
      );
    case "small":
      return (
        <g>
          <path d="M92,130 Q100,135 108,130" stroke="#a3322f" strokeWidth="2.5" fill="none" strokeLinecap="round" />
          <ellipse cx="100" cy="132" rx="3" ry="1.5" fill="#a3322f" opacity="0.6" />
        </g>
      );
    default:
      return (
        <g>
          <path d="M80,126 Q100,144 120,126" fill="none" stroke="#a3322f" strokeWidth="3.5" strokeLinecap="round" />
          <path d="M84,128 Q100,140 116,128" fill="#ff8aa0" opacity="0.4" />
        </g>
      );
  }
}

/* ---------------- FACE ACCESSORY ---------------- */
function FaceAcc({ id }: { id: string }) {
  switch (id) {
    case "glasses":
      return (
        <g fill="none" stroke="#1f2937" strokeWidth="2.6">
          <circle cx="80" cy="104" r="14" fill="rgba(186,230,253,0.25)" />
          <circle cx="120" cy="104" r="14" fill="rgba(186,230,253,0.25)" />
          <path d="M94,104 Q100,100 106,104" />
          <line x1="66" y1="100" x2="60" y2="98" />
          <line x1="134" y1="100" x2="140" y2="98" />
        </g>
      );
    case "sunglasses":
      return (
        <g>
          <rect x="62" y="94" width="34" height="18" rx="6" fill="#0f172a" />
          <rect x="104" y="94" width="34" height="18" rx="6" fill="#0f172a" />
          <line x1="96" y1="103" x2="104" y2="103" stroke="#0f172a" strokeWidth="3" />
          <path d="M66 98 L78 98" stroke="#fff" strokeWidth="2" opacity="0.55" />
          <path d="M108 98 L120 98" stroke="#fff" strokeWidth="2" opacity="0.55" />
        </g>
      );
    case "hat":
      return (
        <g>
          <ellipse cx="100" cy="58" rx="76" ry="9" fill="#1f2937" />
          <path d="M64,22 Q100,8 136,22 L136,58 L64,58 Z" fill="#1f2937" />
          <rect x="64" y="50" width="72" height="6" fill="#dc2626" />
          <circle cx="92" cy="53" r="2" fill="#fbbf24" />
        </g>
      );
    case "cap":
      return (
        <g>
          <path d="M48,62 Q100,26 152,62 L152,72 Q100,58 48,72 Z" fill="#dc2626" />
          <path d="M100,64 L168,64 L160,76 L100,70 Z" fill="#b91c1c" />
          <circle cx="100" cy="48" r="5" fill="#fbbf24" stroke="#b45309" strokeWidth="0.8" />
        </g>
      );
    case "crown":
      return (
        <g>
          <path d="M52,46 L72,16 L92,46 L112,16 L132,46 L152,16 L152,58 L52,58 Z" fill="#facc15" stroke="#ca8a04" strokeWidth="1.5" />
          <circle cx="72" cy="20" r="3.5" fill="#ef4444" />
          <circle cx="112" cy="20" r="3.5" fill="#3b82f6" />
          <circle cx="152" cy="20" r="3.5" fill="#10b981" />
          <rect x="56" y="50" width="92" height="7" fill="#ca8a04" />
          <circle cx="78" cy="54" r="2" fill="#fff" opacity="0.6" />
        </g>
      );
    case "earrings":
      return (
        <g>
          <circle cx="44" cy="118" r="2.5" fill="#fbbf24" />
          <circle cx="156" cy="118" r="2.5" fill="#fbbf24" />
          <circle cx="44" cy="124" r="4.5" fill="#facc15" stroke="#ca8a04" strokeWidth="0.8" />
          <circle cx="156" cy="124" r="4.5" fill="#facc15" stroke="#ca8a04" strokeWidth="0.8" />
        </g>
      );
    default:
      return null;
  }
}

/* ---------------- OUTFIT VARIANTS ---------------- */
function Outfit({ kind, color }: { kind: string; color: string }) {
  const dark = shade(color, -32);
  const darker = shade(color, -48);
  switch (kind) {
    case "hoodie":
      return (
        <g>
          {/* hood */}
          <path d="M60,168 Q100,140 140,168 L134,190 Q100,176 66,190 Z" fill={dark} />
          {/* pocket */}
          <path d="M70,196 L130,196 L126,210 L74,210 Z" fill={dark} opacity="0.7" />
          <line x1="100" y1="196" x2="100" y2="210" stroke={darker} strokeWidth="1" />
          {/* strings */}
          <line x1="92" y1="170" x2="92" y2="186" stroke="#fff" strokeWidth="1.5" />
          <line x1="108" y1="170" x2="108" y2="186" stroke="#fff" strokeWidth="1.5" />
          <circle cx="92" cy="187" r="2" fill="#fff" />
          <circle cx="108" cy="187" r="2" fill="#fff" />
        </g>
      );
    case "jacket":
      return (
        <g>
          {/* lapels */}
          <path d="M100,160 L78,170 L86,210 L100,200 Z" fill={dark} />
          <path d="M100,160 L122,170 L114,210 L100,200 Z" fill={dark} />
          {/* zipper */}
          <line x1="100" y1="162" x2="100" y2="218" stroke={darker} strokeWidth="2" />
          <circle cx="100" cy="178" r="2.5" fill="#fde047" stroke={darker} strokeWidth="0.5" />
          <circle cx="100" cy="195" r="2.5" fill="#fde047" stroke={darker} strokeWidth="0.5" />
          <circle cx="100" cy="210" r="2.5" fill="#fde047" stroke={darker} strokeWidth="0.5" />
        </g>
      );
    case "soccer":
      return (
        <g>
          {/* vertical stripes */}
          <rect x="68" y="160" width="8" height="58" fill="#fff" opacity="0.75" />
          <rect x="92" y="160" width="8" height="58" fill="#fff" opacity="0.75" />
          <rect x="116" y="160" width="8" height="58" fill="#fff" opacity="0.75" />
          <text x="100" y="205" textAnchor="middle" fontSize="16" fontWeight="bold" fill="#fff" stroke={darker} strokeWidth="0.6">10</text>
        </g>
      );
    case "dress":
      return (
        <g>
          {/* dress flare */}
          <path d="M70,180 Q100,168 130,180 L150,222 L50,222 Z" fill={shade(color, -10)} />
          <circle cx="80" cy="200" r="3" fill="#fff" opacity="0.7" />
          <circle cx="120" cy="206" r="3" fill="#fff" opacity="0.7" />
          <circle cx="100" cy="216" r="3" fill="#fff" opacity="0.7" />
        </g>
      );
    default:
      // basic tee: subtle hem line
      return <path d="M40,210 Q100,224 160,210" stroke={darker} strokeWidth="1.5" fill="none" opacity="0.55" />;
  }
}

/* ---------------- BODY ACCESSORY ---------------- */
function Accessory({ id, color }: { id: string; color: string }) {
  switch (id) {
    case "necklace":
      return (
        <g>
          <path d="M70,162 Q100,184 130,162" stroke="#facc15" strokeWidth="2.8" fill="none" />
          <path d="M96,178 L100,184 L104,178 L100,182 Z" fill="#fbbf24" stroke="#ca8a04" strokeWidth="0.8" />
          <circle cx="100" cy="180" r="3" fill="#fde68a" />
        </g>
      );
    case "bracelet":
      return (
        <g>
          <circle cx="40" cy="200" r="6" fill="#10b981" stroke="#047857" strokeWidth="1.2" />
          <circle cx="40" cy="200" r="2" fill="#fff" opacity="0.7" />
        </g>
      );
    case "backpack":
      return (
        <g>
          <path d="M22,168 L22,214 Q22,220 30,220 L46,220 L46,168 Z" fill={shade(color, -45)} />
          <path d="M154,168 L154,220 L170,220 Q178,220 178,214 L178,168 Z" fill={shade(color, -45)} />
          <rect x="26" y="180" width="16" height="8" rx="2" fill={shade(color, -55)} />
        </g>
      );
    case "cape":
      return (
        <g>
          <path d="M40,158 Q100,196 160,158 L172,222 L28,222 Z" fill="#7c3aed" opacity="0.9" />
          <path d="M40,158 Q100,196 160,158" stroke="#5b21b6" strokeWidth="2" fill="none" />
        </g>
      );
    default:
      return null;
  }
}

function shade(hex: string, percent: number) {
  const num = parseInt(hex.replace("#", ""), 16);
  const amt = Math.round(2.55 * percent);
  const r = Math.max(0, Math.min(255, (num >> 16) + amt));
  const g = Math.max(0, Math.min(255, ((num >> 8) & 0xff) + amt));
  const b = Math.max(0, Math.min(255, (num & 0xff) + amt));
  return "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
}
