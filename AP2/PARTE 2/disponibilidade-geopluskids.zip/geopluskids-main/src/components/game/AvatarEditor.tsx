import { useProfile } from "@/lib/game/ProfileContext";
import {
  SKIN_TONES, HAIR_COLORS, HAIR_STYLES, EYE_STYLES, BROW_STYLES,
  MOUTH_STYLES, FACE_ACCESSORIES, OUTFITS, ACCESSORIES, CLOTH_COLORS,
  type AvatarConfig,
} from "@/lib/game/constants";
import { AvatarRenderer } from "./AvatarRenderer";
import { toast } from "sonner";

export default function AvatarEditor({ onBack }: { onBack: () => void }) {
  const { profile, setAvatar, addUnlocked } = useProfile();
  if (!profile) return null;
  const a = profile.avatar;

  const update = (patch: Partial<AvatarConfig>) => setAvatar({ ...a, ...patch });

  const tryBuy = async (itemId: string, price: number, apply: () => void) => {
    if (price === 0 || profile.unlocked.includes(itemId)) {
      apply();
      return;
    }
    if (profile.xp < price) {
      toast.error(`Você precisa de ${price} XP. Você tem ${profile.xp}.`);
      return;
    }
    if (!confirm(`Comprar por ${price} XP?`)) return;
    await addUnlocked([itemId], price);
    apply();
    toast.success("Desbloqueado! 🎉");
  };

  return (
    <div className="grid gap-4 md:grid-cols-[280px_1fr]">
      <div className="card-toy text-center">
        <button onClick={onBack} className="btn-toy btn-secondary mb-3">← Voltar</button>
        <AvatarRenderer a={a} size={220} />
        <div className="mt-2 font-display text-xl">{profile.username}</div>
        <div className="text-sm">⭐ {profile.xp} XP</div>
      </div>

      <div className="space-y-4">
        <Section title="Tom de pele">
          <ColorRow colors={SKIN_TONES} value={a.skin} onPick={(c) => update({ skin: c })} />
        </Section>
        <Section title="Cabelo">
          <PartGrid
            items={HAIR_STYLES.map((s) => ({ id: s, label: s }))}
            value={a.hairStyle}
            onPick={(s) => update({ hairStyle: s as never })}
          />
          <ColorRow colors={HAIR_COLORS} value={a.hairColor} onPick={(c) => update({ hairColor: c })} />
        </Section>
        <Section title="Sobrancelha">
          <PartGrid items={BROW_STYLES.map((s) => ({ id: s, label: s }))} value={a.brow} onPick={(s) => update({ brow: s as never })} />
        </Section>
        <Section title="Olhos">
          <PartGrid items={EYE_STYLES.map((s) => ({ id: s, label: s }))} value={a.eye} onPick={(s) => update({ eye: s as never })} />
          <ColorRow colors={HAIR_COLORS} value={a.eyeColor} onPick={(c) => update({ eyeColor: c })} />
        </Section>
        <Section title="Boca">
          <PartGrid items={MOUTH_STYLES.map((s) => ({ id: s, label: s }))} value={a.mouth} onPick={(s) => update({ mouth: s as never })} />
        </Section>
        <Section title="Acessório de rosto">
          <ShopGrid
            items={FACE_ACCESSORIES.map((it) => ({ id: it.id, label: it.name, price: it.price }))}
            value={a.face}
            unlocked={profile.unlocked}
            onPick={(id, price) => tryBuy("face:" + id, price, () => update({ face: id }))}
          />
        </Section>
        <Section title="Roupa">
          <ShopGrid
            items={OUTFITS.map((it) => ({ id: it.id, label: it.name, price: it.price }))}
            value={a.outfit}
            unlocked={profile.unlocked}
            onPick={(id, price) => tryBuy("outfit:" + id, price, () => update({ outfit: id }))}
          />
          <ColorRow colors={CLOTH_COLORS} value={a.outfitColor} onPick={(c) => update({ outfitColor: c })} />
        </Section>
        <Section title="Acessório">
          <ShopGrid
            items={ACCESSORIES.map((it) => ({ id: it.id, label: it.name, price: it.price }))}
            value={a.accessory}
            unlocked={profile.unlocked}
            onPick={(id, price) => tryBuy("acc:" + id, price, () => update({ accessory: id }))}
          />
        </Section>
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="card-toy">
      <h3 className="font-display text-lg font-bold mb-2">{title}</h3>
      <div className="space-y-2">{children}</div>
    </div>
  );
}

function ColorRow({ colors, value, onPick }: { colors: readonly string[]; value: string; onPick: (c: string) => void }) {
  return (
    <div className="flex flex-wrap gap-2">
      {colors.map((c) => (
        <button
          key={c}
          onClick={() => onPick(c)}
          style={{ background: c }}
          className={`h-8 w-8 rounded-full border-2 ${value === c ? "border-primary scale-110" : "border-border"}`}
          aria-label={c}
        />
      ))}
    </div>
  );
}

function PartGrid({ items, value, onPick }: { items: { id: string; label: string }[]; value: string; onPick: (id: string) => void }) {
  return (
    <div className="flex flex-wrap gap-2">
      {items.map((it) => (
        <button
          key={it.id}
          onClick={() => onPick(it.id)}
          className={`rounded-xl px-3 py-1 text-sm capitalize ${value === it.id ? "bg-primary text-primary-foreground" : "bg-muted"}`}
        >
          {it.label}
        </button>
      ))}
    </div>
  );
}

function ShopGrid({
  items, value, unlocked, onPick,
}: {
  items: { id: string; label: string; price: number }[];
  value: string;
  unlocked: string[];
  onPick: (id: string, price: number) => void;
}) {
  return (
    <div className="flex flex-wrap gap-2">
      {items.map((it) => {
        const locked = it.price > 0 && !unlocked.includes(it.label.startsWith("Nenhum") ? "" : `${it.id}`);
        return (
          <button
            key={it.id}
            onClick={() => onPick(it.id, it.price)}
            className={`rounded-xl px-3 py-2 text-sm ${value === it.id ? "bg-primary text-primary-foreground" : "bg-muted"}`}
          >
            {it.label}
            {it.price > 0 && <span className="ml-1 text-xs opacity-70">⭐{it.price}</span>}
          </button>
        );
      })}
    </div>
  );
}
