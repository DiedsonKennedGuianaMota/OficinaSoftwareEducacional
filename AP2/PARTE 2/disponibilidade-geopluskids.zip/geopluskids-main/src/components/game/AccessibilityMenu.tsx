import { useProfile } from "@/lib/game/ProfileContext";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function AccessibilityMenu({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { profile, setAccessibility } = useProfile();
  if (!profile) return null;
  const a = profile.accessibility;

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl">♿ Acessibilidade</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <Row label="Alto contraste">
            <Toggle on={!!a.highContrast} onChange={(v) => setAccessibility({ highContrast: v })} />
          </Row>
          <Row label="Reduzir animações">
            <Toggle on={!!a.reduceMotion} onChange={(v) => setAccessibility({ reduceMotion: v })} />
          </Row>
          <Row label="Fonte para dislexia">
            <Toggle on={!!a.dyslexia} onChange={(v) => setAccessibility({ dyslexia: v })} />
          </Row>
          <Row label="Baixa visão (zoom)">
            <Toggle on={!!a.lowVision} onChange={(v) => setAccessibility({ lowVision: v })} />
          </Row>
          <Row label="Narrar instruções 🔊">
            <Toggle on={!!a.narrate} onChange={(v) => setAccessibility({ narrate: v })} />
          </Row>
          <Row label="Tamanho da letra">
            <div className="flex gap-1">
              {(["sm", "md", "lg", "xl"] as const).map((s) => (
                <button
                  key={s}
                  onClick={() => setAccessibility({ fontSize: s })}
                  className={`rounded-lg px-3 py-1 text-sm ${a.fontSize === s ? "bg-primary text-primary-foreground" : "bg-muted"}`}
                >
                  {s.toUpperCase()}
                </button>
              ))}
            </div>
          </Row>
          <Row label="Daltonismo">
            <select
              value={a.colorBlind || "none"}
              onChange={(e) => setAccessibility({ colorBlind: e.target.value as never })}
              className="rounded-lg border bg-background p-2"
            >
              <option value="none">Nenhum</option>
              <option value="protan">Protanopia</option>
              <option value="deutan">Deuteranopia</option>
              <option value="tritan">Tritanopia</option>
            </select>
          </Row>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-xl bg-muted/50 p-3">
      <span className="font-semibold">{label}</span>
      {children}
    </div>
  );
}

function Toggle({ on, onChange }: { on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!on)}
      className={`relative h-7 w-12 rounded-full transition ${on ? "bg-success" : "bg-muted-foreground/30"}`}
      aria-pressed={on}
    >
      <span className={`absolute top-1 h-5 w-5 rounded-full bg-white transition ${on ? "left-6" : "left-1"}`} />
    </button>
  );
}
