import { useEffect, useMemo, useState } from "react";
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp } from "lucide-react";
import { Feedback } from "./Feedback";
import { AutoSpeak, SpeakButton } from "./Speak";

interface Props {
  level: number; // 1..5
  onWin: (stars: number, xp: number) => void;
  onLoseLife: () => void;
}

type Pos = { x: number; y: number };
type Landmark = { x: number; y: number; emoji: string; name: string };

const ITEMS = [
  { emoji: "🌳", name: "árvore" },
  { emoji: "🏠", name: "casa" },
  { emoji: "🧸", name: "ursinho" },
  { emoji: "⚽", name: "bola" },
  { emoji: "🚗", name: "carrinho" },
  { emoji: "🌸", name: "flor" },
];

const MISSIONS = [
  { key: "right", text: (l: Landmark) => `Vá à DIREITA do ${l.name}.`, target: (l: Landmark) => ({ x: l.x + 1, y: l.y }) },
  { key: "left", text: (l: Landmark) => `Vá à ESQUERDA do ${l.name}.`, target: (l: Landmark) => ({ x: l.x - 1, y: l.y }) },
  { key: "front", text: (l: Landmark) => `Fique EM FRENTE do ${l.name}.`, target: (l: Landmark) => ({ x: l.x, y: l.y + 1 }) },
  { key: "back", text: (l: Landmark) => `Vá para ATRÁS do ${l.name}.`, target: (l: Landmark) => ({ x: l.x, y: l.y - 1 }) },
];

function rng<T>(arr: T[]) { return arr[Math.floor(Math.random() * arr.length)]; }

function buildRound(level: number, seed: number) {
  const grid = level <= 2 ? 4 : level <= 4 ? 5 : 6;
  const types = level === 1 ? MISSIONS.slice(0, 2) : MISSIONS;
  const used: Pos[] = [];
  const landmarks: Landmark[] = [];
  const count = Math.min(2 + Math.floor(level / 2), 4);
  while (landmarks.length < count) {
    const x = Math.floor(Math.random() * (grid - 2)) + 1;
    const y = Math.floor(Math.random() * (grid - 2)) + 1;
    if (used.some((u) => u.x === x && u.y === y)) continue;
    used.push({ x, y });
    const it = ITEMS[(landmarks.length + seed) % ITEMS.length];
    landmarks.push({ x, y, ...it });
  }
  const l = rng(landmarks);
  const m = rng(types);
  const target = m.target(l);

  // Obstacles appear from level 2. They never overlap landmarks,
  // start (0,0) or the target tile — only the path is dangerous.
  const spikes: Pos[] = [];
  const puddles: Pos[] = []; // slippery: bounces the kid back
  const spikeCount = level <= 1 ? 0 : Math.min(level - 1, 4);
  const puddleCount = level <= 2 ? 0 : Math.min(level - 2, 3);
  const isBlocked = (p: Pos) =>
    (p.x === 0 && p.y === 0) ||
    (p.x === target.x && p.y === target.y) ||
    landmarks.some((l) => l.x === p.x && l.y === p.y) ||
    spikes.some((s) => s.x === p.x && s.y === p.y) ||
    puddles.some((s) => s.x === p.x && s.y === p.y);
  let guard = 0;
  while (spikes.length < spikeCount && guard++ < 60) {
    const p = { x: Math.floor(Math.random() * grid), y: Math.floor(Math.random() * grid) };
    if (!isBlocked(p)) spikes.push(p);
  }
  guard = 0;
  while (puddles.length < puddleCount && guard++ < 60) {
    const p = { x: Math.floor(Math.random() * grid), y: Math.floor(Math.random() * grid) };
    if (!isBlocked(p)) puddles.push(p);
  }
  return { grid, landmarks, mission: m, landmark: l, target, spikes, puddles };
}

export default function PhaseLocation({ level, onWin, onLoseLife }: Props) {
  const TOTAL = 4;
  const [round, setRound] = useState(0);
  const [seed, setSeed] = useState(() => Math.floor(Math.random() * 1000));
  const data = useMemo(() => buildRound(level, seed + round), [level, seed, round]);
  const [pos, setPos] = useState<Pos>({ x: 0, y: 0 });
  const [stars, setStars] = useState(0);
  const [fb, setFb] = useState<{ kind: "ok" | "err" | null; msg: string }>({ kind: null, msg: "" });
  const [attempts, setAttempts] = useState(0);
  const [hitFlash, setHitFlash] = useState<Pos | null>(null);

  useEffect(() => { setPos({ x: 0, y: 0 }); setFb({ kind: null, msg: "" }); setAttempts(0); }, [round, seed]);

  const stepInto = (np: Pos, prev: Pos) => {
    // Spikes hurt and bounce back
    if (data.spikes.some((s) => s.x === np.x && s.y === np.y)) {
      setHitFlash(np);
      setTimeout(() => setHitFlash(null), 350);
      onLoseLife();
      setFb({ kind: "err", msg: "Ai! Cuidado com os espinhos." });
      return prev;
    }
    // Puddles: slip — kid keeps sliding one extra in the same direction
    if (data.puddles.some((p) => p.x === np.x && p.y === np.y)) {
      const dx = np.x - prev.x;
      const dy = np.y - prev.y;
      const slid = {
        x: Math.max(0, Math.min(data.grid - 1, np.x + dx)),
        y: Math.max(0, Math.min(data.grid - 1, np.y + dy)),
      };
      // don't slip onto a spike
      if (data.spikes.some((s) => s.x === slid.x && s.y === slid.y)) {
        setHitFlash(slid);
        setTimeout(() => setHitFlash(null), 350);
        onLoseLife();
        setFb({ kind: "err", msg: "Escorregou no espinho! 💧" });
        return np;
      }
      setFb({ kind: "err", msg: "Você escorregou na poça! 💧" });
      return slid;
    }
    return np;
  };

  const move = (dx: number, dy: number) =>
    setPos((p) => {
      const np = { x: Math.max(0, Math.min(data.grid - 1, p.x + dx)), y: Math.max(0, Math.min(data.grid - 1, p.y + dy)) };
      if (np.x === p.x && np.y === p.y) return p;
      return stepInto(np, p);
    });

  const check = () => {
    if (pos.x === data.target.x && pos.y === data.target.y) {
      const gained = attempts === 0 ? 2 : 1;
      setStars((s) => s + gained);
      setFb({ kind: "ok", msg: "Boa! 🎉" });
      setTimeout(() => {
        if (round + 1 >= TOTAL) {
          onWin(stars + gained, (stars + gained) * 5 + level * 5);
        } else {
          setRound((r) => r + 1);
        }
      }, 1100);
    } else {
      setAttempts((a) => a + 1);
      onLoseLife();
      setFb({ kind: "err", msg: "Quase! Olhe o objeto e tente de novo." });
    }
  };

  const txt = data.mission.text(data.landmark);

  return (
    <section className="grid gap-4">
      <AutoSpeak text={txt} />
      <div className="card-toy">
        <div className="flex items-center justify-between mb-1">
          <span className="text-xs font-bold text-muted-foreground">Nível {level} · Missão {round + 1}/{TOTAL}</span>
          <button onClick={() => setSeed(Math.random() * 1000)} className="text-xs underline">🎲 sortear outro</button>
        </div>
        <div className="flex items-center gap-2">
          <h2 className="font-display text-2xl font-bold">{txt}</h2>
          <SpeakButton text={txt} />
        </div>

        {level >= 2 && (
          <div className="mt-1 text-xs text-muted-foreground">
            ⚠️ Cuidado: espinhos tiram vida{level >= 3 ? ", poças fazem escorregar" : ""}.
          </div>
        )}

        <div
          className="mt-4 grid gap-1 rounded-2xl bg-muted/60 p-3"
          style={{ gridTemplateColumns: `repeat(${data.grid}, minmax(0, 1fr))` }}
        >
          {Array.from({ length: data.grid * data.grid }).map((_, i) => {
            const x = i % data.grid;
            const y = Math.floor(i / data.grid);
            const lm = data.landmarks.find((l) => l.x === x && l.y === y);
            const isGeo = pos.x === x && pos.y === y;
            const isRef = data.landmark.x === x && data.landmark.y === y;
            const isSpike = data.spikes.some((s) => s.x === x && s.y === y);
            const isPuddle = data.puddles.some((p) => p.x === x && p.y === y);
            const isHit = hitFlash && hitFlash.x === x && hitFlash.y === y;
            return (
              <div
                key={i}
                className={`relative grid aspect-square place-items-center rounded-xl border-2 text-3xl transition-colors ${
                  isHit ? "border-rose-500 bg-rose-200" :
                  isRef ? "border-secondary bg-secondary/10" :
                  "border-transparent bg-card"
                }`}
              >
                {isSpike && (
                  <svg viewBox="0 0 40 40" className="absolute inset-1 w-[85%] h-[85%]">
                    <polygon points="4,34 10,12 16,34" fill="#6b7280" stroke="#1f2937" strokeWidth="1.5" />
                    <polygon points="14,34 20,8 26,34" fill="#9ca3af" stroke="#1f2937" strokeWidth="1.5" />
                    <polygon points="24,34 30,14 36,34" fill="#6b7280" stroke="#1f2937" strokeWidth="1.5" />
                    <line x1="2" y1="35" x2="38" y2="35" stroke="#1f2937" strokeWidth="2" />
                  </svg>
                )}
                {isPuddle && (
                  <svg viewBox="0 0 40 40" className="absolute inset-1 w-[85%] h-[85%]">
                    <ellipse cx="20" cy="26" rx="16" ry="8" fill="#38bdf8" opacity="0.85" />
                    <ellipse cx="14" cy="22" rx="4" ry="1.5" fill="#fff" opacity="0.7" />
                  </svg>
                )}
                {lm?.emoji}
                {isGeo && <span className="pop-in absolute text-4xl drop-shadow-md">🧒</span>}
              </div>
            );
          })}
        </div>

        <div className="mt-4 mx-auto grid grid-cols-3 gap-2 max-w-xs">
          <span />
          <button className="btn-toy btn-secondary !py-2" onClick={() => move(0, -1)} aria-label="cima"><ArrowUp /></button>
          <span />
          <button className="btn-toy btn-secondary !py-2" onClick={() => move(-1, 0)} aria-label="esquerda"><ArrowLeft /></button>
          <button className="btn-toy btn-success !py-2" onClick={check} aria-label="confirmar">✓</button>
          <button className="btn-toy btn-secondary !py-2" onClick={() => move(1, 0)} aria-label="direita"><ArrowRight /></button>
          <span />
          <button className="btn-toy btn-secondary !py-2" onClick={() => move(0, 1)} aria-label="baixo"><ArrowDown /></button>
          <span />
        </div>

        <div className="mt-3"><Feedback kind={fb.kind} message={fb.msg} /></div>
      </div>
    </section>
  );
}

