import { useEffect, useState } from "react";
import { Lock, MapPin, Box, Shapes } from "lucide-react";
import { useProfile } from "@/lib/game/ProfileContext";
import { loadProgress } from "@/lib/game/profile";

type ProgressRow = { phase: number; level: number; best_stars: number };

export default function PhaseSelect({
  onPick, onBack,
}: {
  onPick: (phase: number, level: number) => void;
  onBack: () => void;
}) {
  const { profile } = useProfile();
  const [progress, setProgress] = useState<ProgressRow[]>([]);

  useEffect(() => {
    if (profile) loadProgress(profile.id).then((r) => setProgress(r as ProgressRow[]));
  }, [profile]);

  const phases = [
    {
      id: 1,
      title: "Onde Estou?",
      desc: "Aprenda direita, esquerda, frente e atrás.",
      icon: MapPin,
      gradient: "from-rose-400 to-pink-500",
    },
    {
      id: 2,
      title: "Sólidos do Reino",
      desc: "Esfera, cubo, cone e cilindro.",
      icon: Box,
      gradient: "from-amber-400 to-orange-500",
    },
    {
      id: 3,
      title: "Labirinto das Formas",
      desc: "Pegue as formas certas e fuja.",
      icon: Shapes,
      gradient: "from-violet-500 to-fuchsia-500",
    },
  ];

  const isPhaseUnlocked = (phaseId: number) => {
    if (phaseId === 1) return true;
    const prev = progress.find((p) => p.phase === phaseId - 1);
    return !!prev && prev.level >= 5;
  };

  return (
    <div className="space-y-4">
      <button onClick={onBack} className="btn-toy btn-secondary !py-2 !px-4 !text-base">← Voltar</button>

      <div className="card-toy text-center !py-4">
        <h2 className="font-display text-2xl font-bold">Sua Jornada Geométrica</h2>
        <p className="text-sm text-muted-foreground">Complete uma fase para liberar a próxima.</p>
      </div>

      <div className="space-y-4">
        {phases.map((p, idx) => {
          const r = progress.find((x) => x.phase === p.id);
          const maxLevel = r?.level || 1;
          const unlocked = isPhaseUnlocked(p.id);
          const Icon = p.icon;
          const isComplete = (r?.level || 0) >= 5;

          return (
            <div key={p.id} className="relative">
              {/* connector line */}
              {idx > 0 && (
                <div className="absolute left-10 -top-4 w-1 h-4 bg-gradient-to-b from-transparent to-border" />
              )}

              <div className={`card-toy relative overflow-hidden transition ${unlocked ? "" : "opacity-60"}`}>
                {!unlocked && (
                  <div className="absolute inset-0 bg-card/40 backdrop-blur-[1px] grid place-items-center z-10">
                    <div className="flex flex-col items-center gap-1 text-muted-foreground">
                      <Lock className="w-8 h-8" />
                      <span className="font-display text-sm">Termine a fase anterior</span>
                    </div>
                  </div>
                )}

                <div className="flex items-center gap-4">
                  <div className={`shrink-0 w-16 h-16 rounded-2xl bg-gradient-to-br ${p.gradient} grid place-items-center text-white shadow-md ${unlocked && !isComplete ? "bounce-soft" : ""}`}>
                    <Icon className="w-8 h-8" strokeWidth={2.5} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-display font-bold text-muted-foreground">FASE {p.id}</span>
                      {isComplete && <span className="text-xs rounded-full bg-emerald-100 text-emerald-700 px-2 py-0.5 font-bold">Concluída</span>}
                    </div>
                    <div className="font-display text-xl font-bold">{p.title}</div>
                    <div className="text-sm text-muted-foreground">{p.desc}</div>
                  </div>
                </div>

                {/* Level dots */}
                <div className="mt-4 flex items-center gap-2">
                  {[1, 2, 3, 4, 5].map((lv) => {
                    const lvUnlocked = unlocked && lv <= maxLevel;
                    const lvDone = (r?.level || 0) > lv;
                    return (
                      <button
                        key={lv}
                        disabled={!lvUnlocked}
                        onClick={() => onPick(p.id, lv)}
                        className={`relative flex-1 h-12 rounded-xl font-display font-bold transition ${
                          !lvUnlocked
                            ? "bg-muted text-muted-foreground cursor-not-allowed"
                            : lvDone
                            ? "bg-emerald-500 text-white shadow hover:-translate-y-0.5"
                            : "bg-gradient-to-br from-primary to-secondary text-primary-foreground shadow-md hover:-translate-y-0.5"
                        }`}
                        aria-label={`Nível ${lv}`}
                      >
                        {lvUnlocked ? lv : <Lock className="w-4 h-4 mx-auto" />}
                      </button>
                    );
                  })}
                </div>
                <div className="mt-1 flex justify-between text-[10px] text-muted-foreground font-bold">
                  <span>Início</span>
                  <span>Meio</span>
                  <span>Domínio</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
