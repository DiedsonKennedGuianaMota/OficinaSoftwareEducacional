import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useProfile } from "@/lib/game/ProfileContext";
import { FRUITS, randomFruitPassword, type FruitId } from "@/lib/game/constants";
import { signUpChild } from "@/lib/game/auth";
import { toast } from "sonner";

type ClassRow = { id: string; name: string };
type StudentRow = { id: string; username: string; display_name: string | null; age: number; xp: number };

export default function TeacherDashboard() {
  const { profile, signOut } = useProfile();
  const [classes, setClasses] = useState<ClassRow[]>([]);
  const [selected, setSelected] = useState<string | null>(null);
  const [students, setStudents] = useState<StudentRow[]>([]);
  const [newClass, setNewClass] = useState("");
  const [adding, setAdding] = useState(false);

  const loadClasses = async () => {
    const { data } = await supabase.from("classes").select("id, name").order("created_at");
    setClasses(data || []);
    if (data && data.length && !selected) setSelected(data[0].id);
  };

  const loadStudents = async (classId: string) => {
    const { data: cs } = await supabase.from("class_students").select("student_id").eq("class_id", classId);
    const ids = (cs || []).map((c) => c.student_id);
    if (!ids.length) { setStudents([]); return; }
    const { data: profs } = await supabase.from("profiles").select("id, username, display_name, age, xp").in("id", ids);
    setStudents((profs || []) as StudentRow[]);
  };

  useEffect(() => { loadClasses(); }, []);
  useEffect(() => { if (selected) loadStudents(selected); }, [selected]);

  const createClass = async () => {
    if (!newClass.trim() || !profile) return;
    const { data, error } = await supabase.from("classes").insert({ name: newClass.trim(), teacher_id: profile.id }).select().single();
    if (error) return toast.error(error.message);
    setNewClass("");
    setClasses((c) => [...c, data]);
    setSelected(data.id);
  };

  if (!profile) return null;

  return (
    <div className="space-y-4">
      <div className="card-toy flex items-center justify-between">
        <div>
          <div className="font-display text-2xl font-bold">Olá, prof. {profile.display_name || profile.username} 👩‍🏫</div>
          <div className="text-sm text-muted-foreground">Painel do Professor — GeoPlusKids</div>
        </div>
        <button onClick={signOut} className="btn-toy btn-secondary !py-2 !px-3 !text-sm">Sair</button>
      </div>

      <div className="card-toy">
        <h3 className="font-display text-lg font-bold mb-2">📚 Suas turmas</h3>
        <div className="flex flex-wrap gap-2 mb-3">
          {classes.map((c) => (
            <button key={c.id} onClick={() => setSelected(c.id)} className={`rounded-xl px-3 py-2 text-sm ${selected === c.id ? "bg-primary text-primary-foreground" : "bg-muted"}`}>{c.name}</button>
          ))}
          {!classes.length && <span className="text-sm text-muted-foreground">Nenhuma turma ainda.</span>}
        </div>
        <div className="flex gap-2">
          <input value={newClass} onChange={(e) => setNewClass(e.target.value)} placeholder="Nome da turma" className="flex-1 rounded-xl border-2 border-border bg-background p-2" />
          <button onClick={createClass} className="btn-toy btn-primary !py-2 !px-3 !text-sm">+ Criar</button>
        </div>
      </div>

      {selected && (
        <div className="card-toy">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-display text-lg font-bold">👧 Alunos</h3>
            <button onClick={() => setAdding(true)} className="btn-toy btn-primary !py-2 !px-3 !text-sm">+ Adicionar</button>
          </div>
          {!students.length && <p className="text-sm text-muted-foreground">Nenhum aluno nesta turma.</p>}
          <div className="space-y-2">
            {students.map((s) => (
              <StudentRowCard key={s.id} s={s} />
            ))}
          </div>
        </div>
      )}

      {adding && selected && (
        <AddStudentModal classId={selected} onClose={() => { setAdding(false); if (selected) loadStudents(selected); }} />
      )}
    </div>
  );
}

function StudentRowCard({ s }: { s: StudentRow }) {
  const [progress, setProgress] = useState<{ phase: number; level: number; best_stars: number }[]>([]);
  const [assess, setAssess] = useState<{ score: number; stars: number; total: number } | null>(null);
  useEffect(() => {
    supabase.from("progress").select("phase, level, best_stars").eq("user_id", s.id).then(({ data }) => setProgress(data || []));
    supabase.from("assessments").select("score, stars, total").eq("user_id", s.id).order("completed_at", { ascending: false }).limit(1).then(({ data }) => setAssess(data?.[0] ?? null));
  }, [s.id]);

  return (
    <div className="rounded-xl border-2 border-border p-3">
      <div className="flex items-center justify-between">
        <div className="font-display font-bold">{s.display_name || s.username} <span className="text-xs text-muted-foreground">({s.age} anos)</span></div>
        <div className="text-sm">⭐ {s.xp} XP</div>
      </div>
      <div className="mt-2 grid grid-cols-3 gap-2 text-xs">
        {[1, 2, 3].map((ph) => {
          const p = progress.find((x) => x.phase === ph);
          return (
            <div key={ph} className="rounded bg-muted p-2 text-center">
              <div className="font-bold">Fase {ph}</div>
              <div>Nível {p?.level || 1}/5</div>
              <div className="text-yellow-500">{"⭐".repeat(p?.best_stars || 0) || "—"}</div>
            </div>
          );
        })}
      </div>
      {assess && (
        <div className="mt-2 text-xs rounded bg-amber-100 text-amber-900 p-2">
          🏆 Avaliação: {assess.score}/{assess.total} · {"⭐".repeat(assess.stars)}
        </div>
      )}
    </div>
  );
}

function AddStudentModal({ classId, onClose }: { classId: string; onClose: () => void }) {
  const [name, setName] = useState("");
  const [age, setAge] = useState(6);
  const [fruits] = useState<FruitId[]>(() => randomFruitPassword(4));
  const [loading, setLoading] = useState(false);
  const [created, setCreated] = useState(false);

  const create = async () => {
    if (!name.trim()) return toast.error("Digite o nome.");
    setLoading(true);
    try {
      // 1) capture teacher session BEFORE the signup steals it
      const { data: { session: teacherSession } } = await supabase.auth.getSession();
      if (!teacherSession) throw new Error("Sessão da professora expirou. Faça login de novo.");

      // 2) create child account + profile (this swaps session to the child)
      const userId = await signUpChild({ username: name, age, fruits });

      // 3) restore teacher session BEFORE inserting into class_students
      //    (RLS on class_students requires auth.uid() = teacher_id of the class)
      const { error: restoreErr } = await supabase.auth.setSession({
        access_token: teacherSession.access_token,
        refresh_token: teacherSession.refresh_token,
      });
      if (restoreErr) throw new Error("Não consegui voltar para a conta de professora. Faça login de novo.");

      // 4) now insert membership as the teacher
      const { error: linkErr } = await supabase
        .from("class_students")
        .insert({ class_id: classId, student_id: userId });
      if (linkErr) throw linkErr;

      setCreated(true);
      toast.success("Aluno adicionado à turma!");
    } catch (e) {
      toast.error((e as Error).message);
    } finally { setLoading(false); }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="card-toy max-w-md w-full">
        <h3 className="font-display text-xl font-bold mb-3">Novo aluno</h3>
        {!created ? (
          <>
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Nome do aluno" className="w-full rounded-xl border-2 border-border bg-background p-3 mb-2" />
            <div className="flex gap-1 mb-3">
              {[5, 6, 7, 8, 9, 10].map((n) => (
                <button key={n} onClick={() => setAge(n)} className={`flex-1 rounded p-2 text-sm ${age === n ? "bg-primary text-primary-foreground" : "bg-muted"}`}>{n}</button>
              ))}
            </div>
            <p className="text-sm text-muted-foreground mb-2">Senha de frutas gerada:</p>
            <div className="flex gap-2 justify-center text-4xl mb-3 bg-muted rounded-xl p-3">
              {fruits.map((f, i) => <span key={i}>{FRUITS.find((x) => x.id === f)!.emoji}</span>)}
            </div>
            <div className="flex gap-2">
              <button onClick={onClose} className="btn-toy btn-secondary flex-1">Cancelar</button>
              <button onClick={create} disabled={loading} className="btn-toy btn-primary flex-1">{loading ? "..." : "Criar"}</button>
            </div>
          </>
        ) : (
          <div className="text-center">
            <div className="text-5xl">✅</div>
            <p className="mt-2">Aluno criado! Anote os dados:</p>
            <div className="mt-3 bg-muted rounded-xl p-3 text-left text-sm">
              <div><b>Nome:</b> {name}</div>
              <div className="flex items-center gap-1"><b>Senha:</b> {fruits.map((f, i) => <span key={i}>{FRUITS.find((x) => x.id === f)!.emoji}</span>)}</div>
            </div>
            <button onClick={onClose} className="btn-toy btn-primary mt-4 w-full">OK</button>
          </div>
        )}
      </div>
    </div>
  );
}
