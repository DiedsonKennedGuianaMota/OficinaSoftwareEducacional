import { Volume2 } from "lucide-react";
import { speak } from "@/lib/game/tts";
import { useProfile } from "@/lib/game/ProfileContext";
import { useEffect } from "react";

export function SpeakButton({ text, className = "" }: { text: string; className?: string }) {
  return (
    <button
      type="button"
      aria-label={`Ouvir: ${text}`}
      onClick={() => speak(text)}
      className={`inline-flex items-center justify-center rounded-full bg-secondary p-2 text-secondary-foreground shadow-sm hover:scale-110 transition ${className}`}
    >
      <Volume2 className="h-4 w-4" />
    </button>
  );
}

export function AutoSpeak({ text }: { text: string }) {
  const { profile } = useProfile();
  useEffect(() => {
    if (profile?.accessibility?.narrate) speak(text);
  }, [text, profile?.accessibility?.narrate]);
  return null;
}
