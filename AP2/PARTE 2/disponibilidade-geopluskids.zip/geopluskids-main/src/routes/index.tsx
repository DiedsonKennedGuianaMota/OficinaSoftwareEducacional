import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Toaster } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { ProfileProvider, useProfile } from "@/lib/game/ProfileContext";
import AuthScreen from "@/components/game/AuthScreen";
import Hud from "@/components/game/Hud";
import Home from "@/components/game/Home";
import AccessibilityMenu from "@/components/game/AccessibilityMenu";
import AvatarEditor from "@/components/game/AvatarEditor";
import ThemeSelector from "@/components/game/ThemeSelector";
import ProgressView from "@/components/game/ProgressView";
import PhaseSelect from "@/components/game/PhaseSelect";
import PhaseLocation from "@/components/game/PhaseLocation";
import PhaseSolids from "@/components/game/PhaseSolids";
import PhaseMaze from "@/components/game/PhaseMaze";
import PhaseWin from "@/components/game/PhaseWin";
import PhaseAssessment from "@/components/game/PhaseAssessment";
import GameOver from "@/components/game/GameOver";
import TeacherDashboard from "@/components/game/TeacherDashboard";
import { saveProgress } from "@/lib/game/profile";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "GeoPlusKids — Geometria que vira aventura" },
      { name: "description", content: "Jogo educacional de geometria para o 1º ano. Avatar, fases progressivas, avaliação interativa e painel do professor." },
    ],
  }),
  component: () => (
    <ProfileProvider>
      <Toaster richColors position="top-center" />
      <App />
    </ProfileProvider>
  ),
});

type View =
  | { kind: "home" }
  | { kind: "phases" }
  | { kind: "progress" }
  | { kind: "avatar" }
  | { kind: "themes" }
  | { kind: "assessment" }
  | { kind: "play"; phase: number; level: number }
  | { kind: "win"; phase: number; level: number; stars: number; xp: number }
  | { kind: "over"; phase: number; level: number };

const MAX_LIVES = 3;

function App() {
  const { profile, loading } = useProfile();
  const [authed, setAuthed] = useState(false);
  const [view, setView] = useState<View>({ kind: "home" });
  const [lives, setLives] = useState(MAX_LIVES);
  const [a11yOpen, setA11yOpen] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setAuthed(!!data.session));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => setAuthed(!!session));
    return () => sub.subscription.unsubscribe();
  }, []);

  if (!authed) return <AuthScreen onAuthed={() => setAuthed(true)} />;
  if (loading || !profile) return <div className="p-10 text-center">Carregando...</div>;

  // Teacher view
  if (profile.role === "teacher") {
    return (
      <main className="min-h-dvh">
        <div className="mx-auto max-w-5xl px-3 py-5">
          <TeacherDashboard />
        </div>
      </main>
    );
  }

  const inGame = view.kind === "play" || view.kind === "win" || view.kind === "over" || view.kind === "assessment";

  const startPlay = (phase: number, level: number) => {
    setLives(MAX_LIVES);
    setView({ kind: "play", phase, level });
  };

  const loseLife = () => {
    setLives((l) => {
      const nl = l - 1;
      if (nl <= 0 && view.kind === "play") {
        setView({ kind: "over", phase: view.phase, level: view.level });
      }
      return Math.max(0, nl);
    });
  };

  const win = async (stars: number, xp: number) => {
    if (view.kind !== "play") return;
    await saveProgress(profile.id, view.phase, view.level + 1, stars);
    await import("@/lib/game/profile").then(({ addXp }) => addXp(profile.id, xp));
    setView({ kind: "win", phase: view.phase, level: view.level, stars, xp });
  };

  return (
    <main className="min-h-dvh relative">
      <Hud
        lives={lives}
        maxLives={MAX_LIVES}
        onHome={() => setView({ kind: "home" })}
        onOpenA11y={() => setA11yOpen(true)}
        showInGame={inGame}
      />

      <div className="mx-auto max-w-5xl px-3 py-5 relative z-10">
        {view.kind === "home" && (
          <Home
            onNavigate={(v) => setView({ kind: v } as View)}
            onPlay={() => setView({ kind: "phases" })}
            onAssessment={() => setView({ kind: "assessment" })}
          />
        )}
        {view.kind === "phases" && (
          <PhaseSelect onBack={() => setView({ kind: "home" })} onPick={startPlay} />
        )}
        {view.kind === "progress" && <ProgressView onBack={() => setView({ kind: "home" })} />}
        {view.kind === "avatar" && <AvatarEditor onBack={() => setView({ kind: "home" })} />}
        {view.kind === "themes" && <ThemeSelector onBack={() => setView({ kind: "home" })} />}
        {view.kind === "assessment" && <PhaseAssessment onBack={() => setView({ kind: "home" })} />}
        {view.kind === "play" && view.phase === 1 && (
          <PhaseLocation level={view.level} onWin={win} onLoseLife={loseLife} />
        )}
        {view.kind === "play" && view.phase === 2 && (
          <PhaseSolids level={view.level} onWin={win} onLoseLife={loseLife} />
        )}
        {view.kind === "play" && view.phase === 3 && (
          <PhaseMaze level={view.level} onWin={win} onLoseLife={loseLife} />
        )}
        {view.kind === "win" && (
          <PhaseWin
            phase={view.phase}
            level={view.level}
            stars={view.stars}
            xpGained={view.xp}
            onNext={() => {
              const nextLevel = Math.min(view.level + 1, 5);
              if (view.level < 5) startPlay(view.phase, nextLevel);
              else if (view.phase < 3) startPlay(view.phase + 1, 1);
              else setView({ kind: "home" });
            }}
            onHome={() => setView({ kind: "home" })}
          />
        )}
        {view.kind === "over" && (
          <GameOver
            onRetry={() => startPlay(view.phase, 1)}
            onHome={() => setView({ kind: "home" })}
          />
        )}
      </div>

      <AccessibilityMenu open={a11yOpen} onClose={() => setA11yOpen(false)} />
    </main>
  );
}
