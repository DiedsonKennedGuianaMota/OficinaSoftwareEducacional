import { createRootRoute, HeadContent, Outlet, Scripts } from "@tanstack/react-router";


import appCss from "../styles.css?url";

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "GeoPlusKids — Geometria que vira aventura" },
      { name: "description", content: "GeoPlusKids: jogo educacional de geometria para o 1º ano, com avatar, fases progressivas, avaliação interativa e painel do professor." },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Fredoka:wght@500;600;700&family=Nunito:wght@500;700;900&display=swap" },
    ],
  }),
  shellComponent: RootDocument,
  notFoundComponent: () => <div className="p-10 text-center">Página não encontrada</div>,
});

function RootDocument() {
  return (
    <html lang="pt-BR">
      <head>
        <HeadContent />
      </head>
      <body>
        {/* SVG color-blind filters */}
        <svg width="0" height="0" style={{ position: "absolute" }} aria-hidden="true">
          <defs>
            <filter id="cb-protan">
              <feColorMatrix
                type="matrix"
                values="0.567 0.433 0 0 0
                        0.558 0.442 0 0 0
                        0 0.242 0.758 0 0
                        0 0 0 1 0"
              />
            </filter>
          </defs>
        </svg>
        <Outlet />
        <Scripts />

      </body>
    </html>
  );
}
