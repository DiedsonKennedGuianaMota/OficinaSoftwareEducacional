import { supabase } from "@/integrations/supabase/client";
import { DEFAULT_AVATAR, type AvatarConfig, type ThemeId } from "./constants";

export interface Profile {
  id: string;
  username: string;
  display_name?: string | null;
  age: number | null;
  role: "student" | "teacher";
  xp: number;
  avatar: AvatarConfig;
  theme: ThemeId;
  accessibility: AccessibilityConfig;
  unlocked: string[];
}

export interface AccessibilityConfig {
  highContrast?: boolean;
  fontSize?: "sm" | "md" | "lg" | "xl";
  dyslexia?: boolean;
  lowVision?: boolean;
  colorBlind?: "none" | "protan" | "deutan" | "tritan";
  reduceMotion?: boolean;
  narrate?: boolean;
}

export const DEFAULT_ACCESSIBILITY: AccessibilityConfig = {
  highContrast: false,
  fontSize: "md",
  dyslexia: false,
  lowVision: false,
  colorBlind: "none",
  reduceMotion: false,
  narrate: true,
};

export async function loadProfile(userId: string): Promise<Profile | null> {
  const { data, error } = await supabase
    .from("profiles")
    .select("id, username, display_name, age, role, xp, avatar, theme, accessibility, unlocked")
    .eq("id", userId)
    .maybeSingle();
  if (error || !data) return null;
  return {
    id: data.id,
    username: data.username,
    display_name: (data as { display_name?: string | null }).display_name ?? null,
    age: data.age,
    role: ((data as { role?: string }).role === "teacher" ? "teacher" : "student"),
    xp: data.xp ?? 0,
    avatar: { ...DEFAULT_AVATAR, ...(data.avatar as object) } as AvatarConfig,
    theme: (data.theme || "default") as ThemeId,
    accessibility: { ...DEFAULT_ACCESSIBILITY, ...(data.accessibility as object) },
    unlocked: (data.unlocked as string[]) || [],
  };
}

export async function saveAssessment(userId: string, score: number, stars: number, total: number, details: Record<string, unknown>) {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  await supabase.from("assessments").insert({ user_id: userId, score, stars, total, details: details as any });
}

export async function loadAssessments(userId: string) {
  const { data } = await supabase
    .from("assessments")
    .select("score, stars, total, completed_at")
    .eq("user_id", userId)
    .order("completed_at", { ascending: false });
  return data || [];
}

export async function saveProfile(p: Partial<Profile> & { id: string }) {
  const patch: {
    avatar?: AvatarConfig;
    theme?: string;
    accessibility?: AccessibilityConfig;
    xp?: number;
    unlocked?: string[];
    updated_at?: string;
  } = { updated_at: new Date().toISOString() };
  if (p.avatar) patch.avatar = p.avatar;
  if (p.theme) patch.theme = p.theme;
  if (p.accessibility) patch.accessibility = p.accessibility;
  if (typeof p.xp === "number") patch.xp = p.xp;
  if (p.unlocked) patch.unlocked = p.unlocked;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  await supabase.from("profiles").update(patch as any).eq("id", p.id);
}

export async function addXp(userId: string, amount: number) {
  const { data } = await supabase.from("profiles").select("xp").eq("id", userId).maybeSingle();
  const cur = data?.xp ?? 0;
  await supabase.from("profiles").update({ xp: cur + amount }).eq("id", userId);
  return cur + amount;
}

export async function loadProgress(userId: string) {
  const { data } = await supabase
    .from("progress")
    .select("phase, level, best_stars, plays")
    .eq("user_id", userId);
  return data || [];
}

export async function saveProgress(userId: string, phase: number, level: number, stars: number) {
  const { data: existing } = await supabase
    .from("progress")
    .select("level, best_stars, plays")
    .eq("user_id", userId)
    .eq("phase", phase)
    .maybeSingle();

  if (existing) {
    await supabase
      .from("progress")
      .update({
        level: Math.max(existing.level, level),
        best_stars: Math.max(existing.best_stars, stars),
        plays: (existing.plays || 0) + 1,
        updated_at: new Date().toISOString(),
      })
      .eq("user_id", userId)
      .eq("phase", phase);
  } else {
    await supabase.from("progress").insert({
      user_id: userId,
      phase,
      level,
      best_stars: stars,
      plays: 1,
    });
  }
}
