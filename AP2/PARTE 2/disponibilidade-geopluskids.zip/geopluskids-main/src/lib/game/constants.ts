export const FRUITS = [
  { id: "apple", emoji: "🍎", name: "maçã" },
  { id: "banana", emoji: "🍌", name: "banana" },
  { id: "grape", emoji: "🍇", name: "uva" },
  { id: "strawberry", emoji: "🍓", name: "morango" },
  { id: "orange", emoji: "🍊", name: "laranja" },
  { id: "watermelon", emoji: "🍉", name: "melancia" },
  { id: "kiwi", emoji: "🥝", name: "kiwi" },
  { id: "pineapple", emoji: "🍍", name: "abacaxi" },
] as const;

export type FruitId = (typeof FRUITS)[number]["id"];

export function randomFruitPassword(len = 4): FruitId[] {
  const out: FruitId[] = [];
  for (let i = 0; i < len; i++) {
    out.push(FRUITS[Math.floor(Math.random() * FRUITS.length)].id);
  }
  return out;
}

export const THEMES = [
  { id: "default", name: "Padrão", emoji: "🌈", price: 0 },
  { id: "halloween", name: "Halloween", emoji: "🎃", price: 100 },
  { id: "hellokitty", name: "Hello Kitty", emoji: "🎀", price: 150 },
  { id: "kuromi", name: "Kuromi", emoji: "💀", price: 150 },
  { id: "soccer", name: "Futebol", emoji: "⚽", price: 80 },
  { id: "space", name: "Espaço", emoji: "🚀", price: 120 },
  { id: "ocean", name: "Oceano", emoji: "🌊", price: 80 },
  { id: "horror", name: "Terror", emoji: "👻", price: 200 },
] as const;

export type ThemeId = (typeof THEMES)[number]["id"];

// Avatar parts catalog
export const SKIN_TONES = [
  "#f9d6b3", "#e6b78f", "#c98e69", "#8d5524", "#5b3416",
  "#b6e388", "#9bd4ff", "#ffb3d9", "#d9b3ff",
];

export const HAIR_COLORS = ["#1f1f1f", "#5a3825", "#c79b56", "#e8d97a", "#ff5e8a", "#7b3fff", "#3fb0ff", "#42d36b"];

export const HAIR_STYLES = ["short", "long", "curly", "buzz", "mohawk", "ponytail", "afro", "bun"] as const;
export const EYE_STYLES = ["round", "happy", "sleepy", "star", "heart"] as const;
export const BROW_STYLES = ["normal", "thick", "thin", "raised", "angry"] as const;
export const MOUTH_STYLES = ["smile", "grin", "tongue", "small"] as const;

export const FACE_ACCESSORIES = [
  { id: "none", name: "Nenhum", price: 0 },
  { id: "glasses", name: "Óculos", price: 40 },
  { id: "sunglasses", name: "Óculos escuros", price: 60 },
  { id: "hat", name: "Chapéu", price: 80 },
  { id: "crown", name: "Coroa", price: 200 },
  { id: "cap", name: "Boné", price: 50 },
  { id: "earrings", name: "Brincos", price: 30 },
] as const;

export const OUTFITS = [
  { id: "tshirt", name: "Camiseta", price: 0 },
  { id: "hoodie", name: "Moletom", price: 70 },
  { id: "jacket", name: "Jaqueta", price: 100 },
  { id: "dress", name: "Vestido", price: 90 },
  { id: "soccer", name: "Camisa de futebol", price: 120 },
] as const;

export const ACCESSORIES = [
  { id: "none", name: "Nenhum", price: 0 },
  { id: "necklace", name: "Colar", price: 50 },
  { id: "bracelet", name: "Pulseira", price: 40 },
  { id: "backpack", name: "Mochila", price: 80 },
  { id: "cape", name: "Capa", price: 150 },
] as const;

export const CLOTH_COLORS = ["#ff5e8a", "#3fb0ff", "#42d36b", "#ffb74d", "#a78bfa", "#f87171", "#fbbf24", "#111827", "#ffffff"];

export type AvatarConfig = {
  skin: string;
  hairStyle: typeof HAIR_STYLES[number];
  hairColor: string;
  brow: typeof BROW_STYLES[number];
  eye: typeof EYE_STYLES[number];
  eyeColor: string;
  mouth: typeof MOUTH_STYLES[number];
  face: string; // FACE_ACCESSORIES id
  outfit: string;
  outfitColor: string;
  accessory: string;
};

export const DEFAULT_AVATAR: AvatarConfig = {
  skin: SKIN_TONES[0],
  hairStyle: "short",
  hairColor: HAIR_COLORS[0],
  brow: "normal",
  eye: "round",
  eyeColor: "#222222",
  mouth: "smile",
  face: "none",
  outfit: "tshirt",
  outfitColor: CLOTH_COLORS[0],
  accessory: "none",
};

// XP rewards
export const XP = {
  easyHit: 5,
  midHit: 10,
  hardHit: 20,
  perfectBonus: 50,
};
