import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  loadProfile,
  saveProfile,
  type Profile,
  type AccessibilityConfig,
} from "./profile";
import type { AvatarConfig, ThemeId } from "./constants";

interface Ctx {
  profile: Profile | null;
  loading: boolean;
  refresh: () => Promise<void>;
  setAvatar: (a: AvatarConfig) => Promise<void>;
  setTheme: (t: ThemeId) => Promise<void>;
  setAccessibility: (a: AccessibilityConfig) => Promise<void>;
  addUnlocked: (ids: string[], spendXp: number) => Promise<void>;
  bumpXp: (delta: number) => Promise<void>;
  signOut: () => Promise<void>;
}

const ProfileCtx = createContext<Ctx | null>(null);

export function ProfileProvider({ children }: { children: ReactNode }) {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = async () => {
    const { data } = await supabase.auth.getSession();
    const uid = data.session?.user.id;
    if (!uid) {
      setProfile(null);
      setLoading(false);
      return;
    }
    const p = await loadProfile(uid);
    if (!p) {
      // Orphan auth user without a profile row — sign out so user can retry.
      await supabase.auth.signOut();
      setProfile(null);
      setLoading(false);
      return;
    }
    setProfile(p);
    setLoading(false);
  };

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange(() => {
      void refresh();
    });
    void refresh();
    return () => sub.subscription.unsubscribe();
  }, []);

  // Apply theme + accessibility to <html>
  useEffect(() => {
    const root = document.documentElement;
    root.dataset.theme = profile?.theme || "default";
    const a = profile?.accessibility || {};
    root.classList.toggle("a11y-high-contrast", !!a.highContrast);
    root.classList.toggle("a11y-dyslexia", !!a.dyslexia);
    root.classList.toggle("a11y-low-vision", !!a.lowVision);
    root.classList.toggle("a11y-reduce-motion", !!a.reduceMotion);
    root.dataset.fontSize = a.fontSize || "md";
    root.dataset.cb = a.colorBlind || "none";
  }, [profile?.theme, profile?.accessibility]);

  const ctx: Ctx = {
    profile,
    loading,
    refresh,
    setAvatar: async (avatar) => {
      if (!profile) return;
      setProfile({ ...profile, avatar });
      await saveProfile({ id: profile.id, avatar });
    },
    setTheme: async (theme) => {
      if (!profile) return;
      setProfile({ ...profile, theme });
      await saveProfile({ id: profile.id, theme });
    },
    setAccessibility: async (accessibility) => {
      if (!profile) return;
      const merged = { ...profile.accessibility, ...accessibility };
      setProfile({ ...profile, accessibility: merged });
      await saveProfile({ id: profile.id, accessibility: merged });
    },
    addUnlocked: async (ids, spendXp) => {
      if (!profile) return;
      const unlocked = Array.from(new Set([...profile.unlocked, ...ids]));
      const xp = Math.max(0, profile.xp - spendXp);
      setProfile({ ...profile, unlocked, xp });
      await saveProfile({ id: profile.id, unlocked, xp });
    },
    bumpXp: async (delta) => {
      if (!profile) return;
      const xp = Math.max(0, profile.xp + delta);
      setProfile({ ...profile, xp });
      await saveProfile({ id: profile.id, xp });
    },
    signOut: async () => {
      await supabase.auth.signOut();
      setProfile(null);
    },
  };

  return <ProfileCtx.Provider value={ctx}>{children}</ProfileCtx.Provider>;
}

export function useProfile() {
  const c = useContext(ProfileCtx);
  if (!c) throw new Error("useProfile fora do provider");
  return c;
}
