import { supabase } from "@/integrations/supabase/client";
import type { FruitId } from "./constants";

function slug(name: string) {
  return name.trim().toLowerCase().replace(/[^a-z0-9]/g, "");
}

function emailFor(username: string) {
  return `${slug(username)}@geopluskids.app`;
}

function passwordFor(fruits: FruitId[]) {
  return "fruit-" + fruits.join("-") + "-key!9";
}

export async function signUpChild(opts: {
  username: string;
  age: number;
  fruits: FruitId[];
}) {
  const email = emailFor(opts.username);
  const password = passwordFor(opts.fruits);

  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: { emailRedirectTo: window.location.origin },
  });
  if (error) throw error;
  const userId = data.user?.id;
  if (!userId) throw new Error("Conta não criada.");

  if (!data.session) {
    const { error: signErr } = await supabase.auth.signInWithPassword({ email, password });
    if (signErr) throw signErr;
  }

  const { error: pErr } = await supabase.from("profiles").insert({
    id: userId,
    username: slug(opts.username),
    display_name: opts.username.trim(),
    age: opts.age,
    fruit_password: opts.fruits,
    role: "student",
  });
  if (pErr) throw pErr;

  return userId;
}

export async function loginChild(username: string, fruits: FruitId[]) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email: emailFor(username),
    password: passwordFor(fruits),
  });
  if (error) throw new Error("Nome ou frutas erradas. Tente de novo!");
  return data.user!.id;
}

export async function findUsername(username: string) {
  const { data } = await supabase
    .from("profiles")
    .select("username")
    .eq("username", slug(username))
    .maybeSingle();
  return !!data;
}

export async function signUpTeacher(opts: { name: string; email: string; password: string }) {
  const { data, error } = await supabase.auth.signUp({
    email: opts.email,
    password: opts.password,
    options: { emailRedirectTo: window.location.origin },
  });
  if (error) throw error;
  const userId = data.user?.id;
  if (!userId) throw new Error("Conta não criada.");
  if (!data.session) {
    const { error: signErr } = await supabase.auth.signInWithPassword({ email: opts.email, password: opts.password });
    if (signErr) throw signErr;
  }
  await supabase.from("profiles").insert({
    id: userId,
    username: slug(opts.name) + "_t",
    display_name: opts.name.trim(),
    age: 0,
    fruit_password: [],
    role: "teacher",
    email: opts.email,
  });
  return userId;
}

export async function loginTeacher(email: string, password: string) {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw new Error("Email ou senha incorretos.");
  return data.user!.id;
}

export async function logout() {
  await supabase.auth.signOut();
}
