let voicesCache: SpeechSynthesisVoice[] = [];
function getVoice() {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return null;
  if (voicesCache.length === 0) voicesCache = window.speechSynthesis.getVoices();
  return (
    voicesCache.find((v) => v.lang.toLowerCase().startsWith("pt")) ||
    voicesCache[0] ||
    null
  );
}

export function speak(text: string) {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
  try {
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "pt-BR";
    u.rate = 0.95;
    u.pitch = 1.15;
    const v = getVoice();
    if (v) u.voice = v;
    window.speechSynthesis.speak(u);
  } catch {}
}

export function stopSpeak() {
  if (typeof window !== "undefined" && "speechSynthesis" in window) {
    window.speechSynthesis.cancel();
  }
}
