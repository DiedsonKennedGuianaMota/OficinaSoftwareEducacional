## GeoPlusKids — Refatoração completa

Vou reconstruir o app com identidade **GeoPlusKids**, fluxo didático em 3 fases sequenciais + avaliação final, área do professor e melhorias visuais profundas. Abaixo o plano de entrega.

---

### 1. Identidade e Design System
- Renomear tudo para **GeoPlusKids** (título, head, root, telas, manifest).
- Novo design system em `src/styles.css`: paleta vibrante (azul/coral/amarelo), tipografia "Fredoka" + "Nunito" via `<link>` em `__root.tsx`.
- Ícones SVG customizados (substituir emojis nos botões principais) com animações: `bounce`, `wiggle`, `float`, `pop`, `confetti`, `sparkle`.
- Camada de partículas/decoração animada por tema (folhas, bolhas, estrelas).

### 2. Autenticação
- **Aluno**: cadastro com nome + idade → sistema gera senha de 4 frutas aleatórias (mostra na tela com instrução de memorizar). Login = nome + sequência de frutas.
- **Professor**: cadastro/login com email + senha (Supabase Auth nativo). Flag `role` em `profiles`.
- Tela inicial de seleção: "Sou Aluno 🧒" / "Sou Professor 👩‍🏫".

### 3. Tela inicial do aluno
- **Avatar grande** no topo (renderizado em SVG realista em camadas).
- **Botão JOGAR central gigante** (animado, pulsa) + 4 botões menores ao redor: Progresso, Avatar, Acessibilidade, Tema.
- Saudação personalizada + XP atual + barra de progresso geral.

### 4. Fases (sequência didática com storytelling)
História: **"Geo, o explorador, precisa encontrar o tesouro perdido no Reino das Formas."**

- **Fase 1 — Vila da Localização** (EF01MA11/12): níveis 1→5 progressivos (1 referencial → frente/atrás → 2 referenciais → grid 4x4 → ponto de vista).
- **Fase 2 — Floresta dos Sólidos** (EF01MA13): identificar/relacionar esfera, cubo, cilindro, cone, pirâmide. Níveis 1→5 (2 sólidos → 5 sólidos com tempo).
- **Fase 3 — Caverna das Formas Planas** (EF01MA14): labirinto coletando círculo/quadrado/triângulo/retângulo, fugindo de fantasmas.
- **Avaliação Final Interativa**: mini-game misturando os 3 conteúdos — "Resgate do Tesouro" com 10 desafios variados (drag, clique, navegação), gera relatório com estrelas e badge.

Cada fase: **3 vidas** (perdeu tudo → reinicia do nível 1 da fase), feedback imediato (✓ com som/animação, ✗ com dica), narração via Web Speech API.

### 5. Avatar (mais realista)
Editor com camadas SVG: cor de pele (10), cabelo (estilo + cor), rosto (formato), olhos (formato + cor), sobrancelha, boca, roupa (camiseta/vestido/jaqueta/uniforme), acessórios (óculos, chapéu, mochila, capa), **pose** (em pé, acenando, pulando, sentado) e **fundo do personagem** (céu, floresta, espaço, castelo). Itens premium custam XP.

### 6. Temas do site
Aplicam tokens CSS + camada animada de partículas/decoração:
- Padrão, Halloween 🎃 (abóboras, teias), Hello Kitty 🎀 (rosa, gatos), Espaço 🚀 (estrelas, planetas), Oceano 🌊, Futebol ⚽, Kuromi, Terror.

### 7. Acessibilidade
Alto contraste, fonte (P/M/G/GG), OpenDyslexic, baixa visão (zoom), 3 filtros de daltonismo (protan/deutan/tritan), reduzir movimento, narração TTS, modo leitura simples.

### 8. Painel do Professor
- Criar turma (nome).
- Adicionar alunos manualmente (gera credenciais nome+frutas, mostra para o professor copiar).
- Ver progresso por aluno (fases, níveis, XP, avaliação final).
- Customizar tema/avatar/acessibilidade da turma (padrões).

### 9. Banco de dados (novas tabelas)
- `profiles` (acrescentar `role` aluno/professor, `teacher_id` opcional).
- `classes` (id, teacher_id, name).
- `class_students` (class_id, student_id).
- `assessments` (user_id, score, stars, completed_at, details jsonb).
- Atualizar `progress` para suportar avaliação final.

---

### Entrega
Vou implementar em **uma única passada** (é extenso, mas integrado). Após eu confirmar a migração de banco com você, sigo com todo o frontend + lógica.

**Confirma para eu prosseguir?** Algum ajuste no plano (priorizar algo, simplificar tema/avatar, mudar storytelling)?