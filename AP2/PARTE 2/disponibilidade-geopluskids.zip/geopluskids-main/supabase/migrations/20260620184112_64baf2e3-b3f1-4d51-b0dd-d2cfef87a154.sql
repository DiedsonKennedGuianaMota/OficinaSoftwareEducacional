ALTER TABLE public.profiles DROP CONSTRAINT IF EXISTS profiles_age_check;
ALTER TABLE public.profiles ALTER COLUMN age DROP NOT NULL;
ALTER TABLE public.profiles ALTER COLUMN fruit_password DROP NOT NULL;
ALTER TABLE public.profiles ADD CONSTRAINT profiles_age_check CHECK (age IS NULL OR age BETWEEN 0 AND 120);